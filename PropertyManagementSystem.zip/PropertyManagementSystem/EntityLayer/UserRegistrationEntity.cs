﻿using System;
using System.Collections.Generic;
using System.Text;
using PropertyManagementSystem.AppLayer;


namespace PropertyManagementSystem.EntityLayer
{
    public class UserRegistrationEntity
    {
        private string name;
        private string password;
        private string email;
        private string phone;
        private string role;
        private string userName;

        public string Name
        {
            get
            {
                return this.name;
            }
            set
            {
                this.name = value;
            }
        }

        public string Password
        {
            get
            {
                return this.password;
            }
            set
            {
                this.password = value;
            }
        }

        public string Email
        {
            get
            {
                return this.email;
            }
            set
            {
                this.email = value;
            }
        }

        public string Phone
        {
            get
            {
                return this.phone;
            }
            set
            {
                this.phone = value;
            }
        }

        public string Role
        {
            get
            {
                return this.role;
            }
            set
            {
                this.role = value;
            }
        }

        public string UserName
        {
            get
            {
                return this.userName;
            }
            set
            {
                this.userName = value;
            }
        }
    }
}
