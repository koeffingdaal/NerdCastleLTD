﻿using System;
using System.Collections.Generic;
using System.Text;


namespace PropertyManagementSystem.EntityLayer
{
    class AdminEntity
    {
        private string adminName;
        private string adminEmail;
        private string adminPhone;

        public string AdminName
        {
            get
            {
                return this.adminName;
            }
            set
            {
                this.adminName = value ;
            }
        }

        public string AdminEmail
        {
            get
            {
                return this.adminEmail;
            }
            set
            {
                this.adminEmail = value;
            }
        }

        public string AdminPhone
        {
            get
            {
                return this.adminPhone;
            }
            set
            {
                this.adminPhone = value;
            }
        }
    }
}
