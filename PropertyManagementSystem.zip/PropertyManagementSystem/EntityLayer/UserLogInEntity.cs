﻿using System;
using System.Collections.Generic;
using System.Text;
using PropertyManagementSystem.AppLayer;

namespace PropertyManagementSystem.EntityLayer
{
    class UserLogInEntity
    {
        private string userId;
        private string userPassword;

        public string UserName
        {
            get
            {
                return this.userId;
            }
            set
            {
                this.userId = value;
            }
        }

        public string UserPassword
        {
            get
            {
                return this.userPassword;
            }
            set
            {
                this.userPassword = value;
            }
        }
    }
}
