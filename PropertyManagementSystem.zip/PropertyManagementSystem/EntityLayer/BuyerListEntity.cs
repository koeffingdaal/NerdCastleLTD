﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PropertyManagementSystem.EntityLayer
{
    class BuyerListEntity
    {
        private string searchBuyerName;

        private string buyerId;
        private string buyerUserName;
        private string buyerRole;
        private string buyerName;
        private string buyerPhone;
        private string buyerEmail;

        public string BuyerId
        {
            get
            {
                return buyerId;
            }
            set
            {
                buyerId = value;
            }
        }

        public string BuyerUserName
        {
            get
            {
                return buyerUserName;
            }
            set
            {
                buyerUserName = value;
            }
        }

        public string BuyerRole
        {
            get
            {
                return buyerRole;
            }
            set
            {
                buyerRole = value;
            }
        }
        public string BuyerName
        {
            get
            {
                return buyerName;
            }
            set
            {
                buyerName = value;
            }
        }

        public string BuyerPhone
        {
            get
            {
                return buyerPhone;
            }
            set
            {
                buyerPhone = value;
            }
        }

        public string BuyerEmail
        {
            get
            {
                return buyerEmail;
            }
            set
            {
                buyerEmail = value;
            }
        }
        public string SearchBuyerName
        {
            get
            {
                return searchBuyerName;
            }
            set
            {
                searchBuyerName = value;
            }
        }
    }
}
