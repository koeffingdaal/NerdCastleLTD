﻿using System;
using System.Collections.Generic;
using System.Text;


namespace PropertyManagementSystem.EntityLayer
{
    class OpenSearchAppIdEntity
    {
        private string searchAppId;

        public string SearchAppId
        {
            get
            {
                return searchAppId;
            }
            set
            {
                this.searchAppId = value;
            }
        }
    }
}
