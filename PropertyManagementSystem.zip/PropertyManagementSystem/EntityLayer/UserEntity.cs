﻿using System;
using System.Collections.Generic;
using System.Text;


namespace PropertyManagementSystem.EntityLayer
{
    class UserEntity
    {
        private string name;
        private string email;
        private string phone;
        private string password;
        private string userName;
        private string searchUname;

        public string SearchUname
        {
            get
            {
                return this.searchUname;
            }
            set
            {
                this.searchUname = value;
            }
        }

        public string Name
        {
            get
            {
                return this.name;
            }
            set
            {
                this.name = value;
            }
        }

        public string Email
        {
            get
            {
                return this.email;
            }
            set
            {
                this.email = value;
            }
        }

        public string Phone
        {
            get
            {
                return this.phone;
            }
            set
            {
                this.phone = value;
            }
        }

        public string Password
        {
            get
            {
                return this.password;
            }
            set
            {
                this.password = value;
            }
        }

        public string UserName
        {
            get
            {
                return this.UserName;
            }
            set
            {
                this.UserName = value;
            }
        }
    }
}
