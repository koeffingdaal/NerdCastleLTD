﻿using System;
using System.Collections.Generic;
using System.Text;


namespace PropertyManagementSystem.EntityLayer
{
    class OpenSpaceEntity
    {
        private string area;
        private string district;
        private string appId;

        private double price;
        private int size;
        private DateTime issueDate;

        public string Area
        {
            get
            {
                return this.area;
            }
            set
            {
                this.area = value;
            }
        }
        public string District
        {
            get
            {
                return this.district;
            }
            set
            {
                this.district = value;
            }
        }

        public string AppId
        {
            get
            {
                return this.appId;
            }
            set
            {
                this.appId = "OS-" + value.PadLeft(2, '0');
            }
        }

        public double Price
        {
            get
            {
                return this.price;
            }
            set
            {
                this.price = value;
            }
        }

        public int Size
        {
            get
            {
                return this.size;
            }
            set
            {
                this.size = value;
            }
        }

        public DateTime IssueDate
        {
            get
            {
                return this.issueDate;
            }
            set
            {
                this.issueDate = value;
            }
        }

    }
}
