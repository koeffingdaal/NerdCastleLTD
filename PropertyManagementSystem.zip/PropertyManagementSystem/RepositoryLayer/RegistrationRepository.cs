﻿using System;
using System.Collections.Generic;
using System.Text;
using PropertyManagementSystem.EntityLayer;
using PropertyManagementSystem.AppLayer;
using PropertyManagementSystem.DataLayer;
using PropertyManagementSystem.ValidationLayer;

namespace PropertyManagementSystem.RepositoryLayer
{
    public class RegistrationRepository
    {
        //UserRegistrationEntity a = new UserRegistrationEntity();

        //RegistrationValidation reg = new RegistrationValidation();

        public bool UserRegistration(UserRegistrationEntity a)
        {
            try
            {
                string sql = @"INSERT INTO Registration
                        VALUES('" + a.Name +"', '"+a.Email+"', '"+a.Phone+"','"+a.Password+"','"+a.UserName+"','"+a.Role+"' );";
                var da = new DataAccess();
                da.ExecuteQuery(sql);
                return true;
            }
            catch(Exception exc)
            {
                return false;
            }
        }
    }
}
