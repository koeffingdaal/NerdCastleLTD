﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using PropertyManagementSystem.DataLayer;
using PropertyManagementSystem.EntityLayer;

namespace PropertyManagementSystem.RepositoryLayer
{
    class BuyerRepo
    {
        private DataAccess Da { get; set; }

        BuyerListEntity ble = new BuyerListEntity();

        public BuyerRepo()
        {
            this.Da = new DataAccess();
        }

        public DataTable AllBuyer()
        {
            string sql = "select * from Registration where Role = 'Buyer';";
            var dt = Da.GetDataTable(sql);
            return dt;

        }

        public DataTable SearchByName(String name)
        {
            
            string sql = "select * from Registration where UserName = '"+name+"';";
            var dt = Da.GetDataTable(sql);
            return dt;
        }

        public void BuyerUpdate(string name, string email, string phone, string uname)
        {

            string sql = @"update Registration
                      SET Name = '" + name + "', Email = '" + email + "', Phone = '" + phone + "' where UserName = '" + uname + "'; ";

            var dt = Da.ExecuteQuery(sql);
        }

        public void BuyerAdd(string name, string email, string phone, string username)
        {

            string sql = @"INSERT INTO Registration
                        VALUES('" + name + "', '" + email + "', '" + phone + "','12345','" + username + "','Buyer' );";
            Da.ExecuteDMLQuery(sql);
        }

        public void DeleteBuyer(string userName)
        {
            var sql = "DELETE FROM Registration WHERE UserName='" + userName + "';";
            Da.ExecuteDMLQuery(sql);

        }
    }
}
