﻿using System;
using System.Collections.Generic;
using System.Text;
using PropertyManagementSystem.DataLayer;
using PropertyManagementSystem.AppLayer;
using PropertyManagementSystem.EntityLayer;

namespace PropertyManagementSystem.RepositoryLayer
{
    class MemberRepo
    {
        
        public static void GetAll()
        {
            
            
            DataAccess Da = new DataAccess();
            string sql = "select * from Registration;";
            Da.ExecuteQuery(sql);
        }

        
    }
}
