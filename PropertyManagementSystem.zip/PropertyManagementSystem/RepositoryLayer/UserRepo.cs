﻿using System;
using System.Collections.Generic;
using System.Text;
using PropertyManagementSystem.DataLayer;
using PropertyManagementSystem.EntityLayer;

namespace PropertyManagementSystem.RepositoryLayer
{
    class UserRepo
    {
        public void Update()
        {
            UserEntity uE = new UserEntity();

            var sql = @"update Registration SET Name = '" + uE.Name + "', Email = '"+uE.Email+"', Phone = '"+uE.Phone+"' where UserName = '"+uE.UserName+"'; ";



            DataAccess da = new DataAccess();
            da.ExecuteDMLQuery(sql);



        }
    }
}
