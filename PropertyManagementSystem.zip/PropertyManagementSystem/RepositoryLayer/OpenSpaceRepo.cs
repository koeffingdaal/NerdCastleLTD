﻿using System;
using System.Collections.Generic;
using System.Text;
using PropertyManagementSystem.DataLayer;
using PropertyManagementSystem.EntityLayer;
using System.Data;


namespace PropertyManagementSystem.RepositoryLayer
{
    class OpenSpaceRepo
    {
        private DataAccess Da;
        
        

        public OpenSpaceRepo()
        {
            this.Da = new DataAccess();
            
            
        }

        public void AddOpenSpace(string appId, string area, string district, DateTime issueDate, double price, int size)
        {

            try
            {
                //this.OSE = ose;
                var sql = @"INSERT INTO ProjectOpenSpace 
                        VALUES('" + appId + "', '" + area + "', '" + district + "', '" + issueDate + "', '" + price + "', '" + size + "'); ";
                this.Da.ExecuteDMLQuery(sql);
            }
            catch(Exception exc)
            {

            }

        }

        public DataTable AllOpenSpace()
        {
            var sql = "select * from ProjectOpenSpace;";
            var dt = this.Da.GetDataTable(sql);
            return dt;
        }

        public void UpdateOpenSpace(string area, string district, double price, int size, DateTime issueDate, string appId)
        {
            try
            {
                string sql = @"update ProjectOpenSpace set Area = '" + area + "', District = '" + district + "', Price = '" + price + "', Size = '" + size + "', IssueDate = '" + issueDate + "'  " +"where AppId = '" + appId + "'; ";
                                

                var dt = this.Da.ExecuteDMLQuery(sql);
            }
            catch(Exception exc)
            {

            }


        }

        public DataTable SearchAppId(string appId)
        {
            string sql = "select * from ProjectOpenSpace where AppId = '"+appId+"';";
            var dt = Da.GetDataTable(sql);
            return dt;
        }

        public void DeleteOpenSpace(string AppId)
        {
            var sql = "DELETE FROM ProjectOpenSpace WHERE AppId='" + AppId + "';";
            Da.ExecuteDMLQuery(sql);
        }
    }
}
