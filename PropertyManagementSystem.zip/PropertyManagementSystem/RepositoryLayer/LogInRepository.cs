﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.ComponentModel;
using System.Threading.Tasks;
using PropertyManagementSystem.EntityLayer;
using PropertyManagementSystem.DataLayer;
using PropertyManagementSystem.AppLayer;
namespace PropertyManagementSystem.RepositoryLayer
{
    class LogInRepository
    {
        AdminEntity aE = new AdminEntity();
        public bool UserLogIn(UserLogInEntity u)
        {
            try
            {
                var sql = "select * from Login where UserName = '" + u.UserName + "' and Password = '" + u.UserPassword + "';";
                DataAccess da = new DataAccess();
                da.ExecuteQuery(sql);

                
                

                if (da.Ds.Tables[0].Rows.Count == 1)
                {

                    
                    
                    return true;
                }

                return false;

            }
           catch(Exception exc)
            {
                return false;
            }
        }

        public void ShowProfile()
        {
            var u = new UserLogInEntity();
            var sql = "select * from Login where Id = '" + u.UserName + "' and Password = '" + u.UserPassword + "';";
            DataAccess da = new DataAccess();
            da.GetDataTable(sql);


            string name = da.Ds.Tables[0].Rows[0][1].ToString();

            if (da.Ds.Tables[0].Rows.Count == 1)
            {

                aE.AdminName = name;
                aE.AdminEmail = da.Ds.Tables[0].Rows[0][2].ToString();


            }
        }
       
    }
}
