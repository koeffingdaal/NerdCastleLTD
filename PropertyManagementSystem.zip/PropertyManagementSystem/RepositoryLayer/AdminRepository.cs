﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

using PropertyManagementSystem.EntityLayer;
using PropertyManagementSystem.ValidationLayer;
using PropertyManagementSystem.DataLayer;
using PropertyManagementSystem.AppLayer;
using PropertyManagementSystem.RepositoryLayer;


namespace PropertyManagementSystem.RepositoryLayer
{
    class AdminRepository
    {
        LogInRepository logInRepo = new LogInRepository();
        public DataTable GetAll()
        {
            DataAccess da = new DataAccess();
            string sql = "select * from Registration;";
            
            var dt = da.GetDataTable(sql);
            
            return dt;



        }

        public void ShowProfile()
        {
            

        }

        
    }
}
