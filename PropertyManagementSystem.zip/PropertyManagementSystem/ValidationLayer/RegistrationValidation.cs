﻿using System;
using System.Collections.Generic;
using System.Text;
using PropertyManagementSystem.EntityLayer;
using PropertyManagementSystem.DataLayer;
using PropertyManagementSystem.AppLayer;

namespace PropertyManagementSystem.ValidationLayer
{
    class RegistrationValidation
    {
        //UserRegistrationEntity u = new UserRegistrationEntity();

        public bool IsEmpty(UserRegistrationEntity u)
        {
            if(String.IsNullOrEmpty(u.Name) || String.IsNullOrEmpty(u.Email) || String.IsNullOrEmpty(u.Phone) || 
                String.IsNullOrEmpty(u.Password) || String.IsNullOrEmpty(u.UserName) || String.IsNullOrEmpty(u.Role))
            {
                return false;
            }
            return true;
        }

        
    }
}
