﻿
namespace PropertyManagementSystem.AppLayer
{
    partial class BuyerList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.dgvAllBuyer = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EMAIL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PHONE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.USERNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ROLE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtUnameSearch = new System.Windows.Forms.TextBox();
            this.mtbtnSearch = new MetroFramework.Controls.MetroButton();
            this.mtbtnShowBuyer = new MetroFramework.Controls.MetroButton();
            this.mtbtnBack = new MetroFramework.Controls.MetroButton();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAllBuyer)).BeginInit();
            this.SuspendLayout();
            // 
            // metroPanel1
            // 
            this.metroPanel1.Controls.Add(this.dgvAllBuyer);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(23, 147);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(730, 413);
            this.metroPanel1.TabIndex = 0;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // dgvAllBuyer
            // 
            this.dgvAllBuyer.AllowUserToAddRows = false;
            this.dgvAllBuyer.AllowUserToDeleteRows = false;
            this.dgvAllBuyer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAllBuyer.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.NAME,
            this.EMAIL,
            this.PHONE,
            this.USERNAME,
            this.ROLE});
            this.dgvAllBuyer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvAllBuyer.Location = new System.Drawing.Point(0, 0);
            this.dgvAllBuyer.Name = "dgvAllBuyer";
            this.dgvAllBuyer.ReadOnly = true;
            this.dgvAllBuyer.RowTemplate.Height = 25;
            this.dgvAllBuyer.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvAllBuyer.Size = new System.Drawing.Size(730, 413);
            this.dgvAllBuyer.TabIndex = 2;
            // 
            // ID
            // 
            this.ID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ID.DataPropertyName = "Id";
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            // 
            // NAME
            // 
            this.NAME.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.NAME.DataPropertyName = "Name";
            this.NAME.HeaderText = "NAME";
            this.NAME.Name = "NAME";
            this.NAME.ReadOnly = true;
            // 
            // EMAIL
            // 
            this.EMAIL.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.EMAIL.DataPropertyName = "Email";
            this.EMAIL.HeaderText = "EMAIL";
            this.EMAIL.Name = "EMAIL";
            this.EMAIL.ReadOnly = true;
            // 
            // PHONE
            // 
            this.PHONE.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.PHONE.DataPropertyName = "Phone";
            this.PHONE.HeaderText = "PHONE";
            this.PHONE.Name = "PHONE";
            this.PHONE.ReadOnly = true;
            // 
            // USERNAME
            // 
            this.USERNAME.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.USERNAME.DataPropertyName = "UserName";
            this.USERNAME.HeaderText = "USERNAME";
            this.USERNAME.Name = "USERNAME";
            this.USERNAME.ReadOnly = true;
            // 
            // ROLE
            // 
            this.ROLE.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ROLE.DataPropertyName = "Role";
            this.ROLE.HeaderText = "ROLE";
            this.ROLE.Name = "ROLE";
            this.ROLE.ReadOnly = true;
            // 
            // txtUnameSearch
            // 
            this.txtUnameSearch.Location = new System.Drawing.Point(264, 44);
            this.txtUnameSearch.Name = "txtUnameSearch";
            this.txtUnameSearch.PlaceholderText = "Search by UserName";
            this.txtUnameSearch.Size = new System.Drawing.Size(204, 23);
            this.txtUnameSearch.TabIndex = 1;
            // 
            // mtbtnSearch
            // 
            this.mtbtnSearch.Location = new System.Drawing.Point(494, 44);
            this.mtbtnSearch.Name = "mtbtnSearch";
            this.mtbtnSearch.Size = new System.Drawing.Size(111, 23);
            this.mtbtnSearch.TabIndex = 2;
            this.mtbtnSearch.Text = "Search";
            this.mtbtnSearch.UseSelectable = true;
            this.mtbtnSearch.Click += new System.EventHandler(this.mtbtnSearch_Click);
            // 
            // mtbtnShowBuyer
            // 
            this.mtbtnShowBuyer.Location = new System.Drawing.Point(631, 44);
            this.mtbtnShowBuyer.Name = "mtbtnShowBuyer";
            this.mtbtnShowBuyer.Size = new System.Drawing.Size(111, 23);
            this.mtbtnShowBuyer.TabIndex = 3;
            this.mtbtnShowBuyer.Text = "All Buyer";
            this.mtbtnShowBuyer.UseSelectable = true;
            this.mtbtnShowBuyer.Click += new System.EventHandler(this.mtbtnShowBuyer_Click);
            // 
            // mtbtnBack
            // 
            this.mtbtnBack.Location = new System.Drawing.Point(687, 118);
            this.mtbtnBack.Name = "mtbtnBack";
            this.mtbtnBack.Size = new System.Drawing.Size(55, 23);
            this.mtbtnBack.TabIndex = 4;
            this.mtbtnBack.Text = "Back";
            this.mtbtnBack.UseSelectable = true;
            this.mtbtnBack.Click += new System.EventHandler(this.mtbtnBack_Click);
            // 
            // BuyerList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(771, 583);
            this.Controls.Add(this.mtbtnBack);
            this.Controls.Add(this.mtbtnShowBuyer);
            this.Controls.Add(this.mtbtnSearch);
            this.Controls.Add(this.txtUnameSearch);
            this.Controls.Add(this.metroPanel1);
            this.Name = "BuyerList";
            this.Text = "BuyerList";
            this.metroPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAllBuyer)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroPanel metroPanel1;
        private System.Windows.Forms.DataGridView dgvAllBuyer;
        private System.Windows.Forms.TextBox txtUnameSearch;
        private MetroFramework.Controls.MetroButton mtbtnSearch;
        private MetroFramework.Controls.MetroButton mtbtnShowBuyer;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn NAME;
        private System.Windows.Forms.DataGridViewTextBoxColumn EMAIL;
        private System.Windows.Forms.DataGridViewTextBoxColumn PHONE;
        private System.Windows.Forms.DataGridViewTextBoxColumn USERNAME;
        private System.Windows.Forms.DataGridViewTextBoxColumn ROLE;
        private MetroFramework.Controls.MetroButton mtbtnBack;
    }
}