﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using PropertyManagementSystem.EntityLayer;
using PropertyManagementSystem.RepositoryLayer;

namespace PropertyManagementSystem.AppLayer
{
    public partial class AddOpenSpace : MetroFramework.Forms.MetroForm
    {

        OpenSpaceEntity openSpaceEntity = new OpenSpaceEntity();

        //private static int count;

        public AddOpenSpace()
        {
            InitializeComponent();
            
        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            try{
                OpenSpaceRepo openSpaceRepo = new OpenSpaceRepo();

                openSpaceEntity.AppId = this.txtAppId.Text;
                openSpaceEntity.Area = this.txtArea.Text;
                openSpaceEntity.District = this.txtDistrict.Text;
                openSpaceEntity.IssueDate = this.mtIssueDate.Value;
                openSpaceEntity.Price = Convert.ToDouble(this.txtPrice.Text);
                openSpaceEntity.Size = Convert.ToInt32(this.txtSize.Text);

                openSpaceRepo.AddOpenSpace(openSpaceEntity.AppId, openSpaceEntity.Area, openSpaceEntity.District, openSpaceEntity.IssueDate, openSpaceEntity.Price, openSpaceEntity.Size);

                MessageBox.Show("Open Space Added");
            }
            catch(Exception exc)
            {
                MessageBox.Show("Submit All Information");
            }



        }

       

       
    }
}
