﻿
namespace PropertyManagementSystem.AppLayer
{
    partial class BuyerDelete
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.dgvBuyerDelete = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EMAIL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PHONE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.USERNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ROLE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mtbtnAllBuyer = new MetroFramework.Controls.MetroButton();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.txtRole = new System.Windows.Forms.TextBox();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.mtlblRole = new MetroFramework.Controls.MetroLabel();
            this.mtlblUsername = new MetroFramework.Controls.MetroLabel();
            this.mtlblPhone = new MetroFramework.Controls.MetroLabel();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtId = new System.Windows.Forms.TextBox();
            this.mtlblEmail = new MetroFramework.Controls.MetroLabel();
            this.mtlblName = new MetroFramework.Controls.MetroLabel();
            this.mtlblId = new MetroFramework.Controls.MetroLabel();
            this.mtbtnSearchBuyer = new MetroFramework.Controls.MetroButton();
            this.txtSearchUname = new System.Windows.Forms.TextBox();
            this.mtbtnDelete = new MetroFramework.Controls.MetroButton();
            this.mtbtnBack = new MetroFramework.Controls.MetroButton();
            this.mtbtnClearContent = new MetroFramework.Controls.MetroButton();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBuyerDelete)).BeginInit();
            this.metroPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dgvBuyerDelete);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(20, 289);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(754, 274);
            this.panel1.TabIndex = 0;
            // 
            // dgvBuyerDelete
            // 
            this.dgvBuyerDelete.AllowUserToAddRows = false;
            this.dgvBuyerDelete.AllowUserToDeleteRows = false;
            this.dgvBuyerDelete.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBuyerDelete.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.NAME,
            this.EMAIL,
            this.PHONE,
            this.USERNAME,
            this.ROLE});
            this.dgvBuyerDelete.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvBuyerDelete.Location = new System.Drawing.Point(0, 0);
            this.dgvBuyerDelete.Name = "dgvBuyerDelete";
            this.dgvBuyerDelete.ReadOnly = true;
            this.dgvBuyerDelete.RowTemplate.Height = 25;
            this.dgvBuyerDelete.Size = new System.Drawing.Size(754, 274);
            this.dgvBuyerDelete.TabIndex = 0;
            this.dgvBuyerDelete.DoubleClick += new System.EventHandler(this.dgvBuyerDelete_DoubleClick);
            // 
            // ID
            // 
            this.ID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ID.DataPropertyName = "Id";
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            // 
            // NAME
            // 
            this.NAME.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.NAME.DataPropertyName = "Name";
            this.NAME.HeaderText = "NAME";
            this.NAME.Name = "NAME";
            this.NAME.ReadOnly = true;
            // 
            // EMAIL
            // 
            this.EMAIL.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.EMAIL.DataPropertyName = "Email";
            this.EMAIL.HeaderText = "EMAIL";
            this.EMAIL.Name = "EMAIL";
            this.EMAIL.ReadOnly = true;
            // 
            // PHONE
            // 
            this.PHONE.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.PHONE.DataPropertyName = "Phone";
            this.PHONE.HeaderText = "PHONE";
            this.PHONE.Name = "PHONE";
            this.PHONE.ReadOnly = true;
            // 
            // USERNAME
            // 
            this.USERNAME.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.USERNAME.DataPropertyName = "UserName";
            this.USERNAME.HeaderText = "USERNAME";
            this.USERNAME.Name = "USERNAME";
            this.USERNAME.ReadOnly = true;
            // 
            // ROLE
            // 
            this.ROLE.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ROLE.DataPropertyName = "Role";
            this.ROLE.HeaderText = "ROLE";
            this.ROLE.Name = "ROLE";
            this.ROLE.ReadOnly = true;
            // 
            // mtbtnAllBuyer
            // 
            this.mtbtnAllBuyer.Location = new System.Drawing.Point(618, 97);
            this.mtbtnAllBuyer.Name = "mtbtnAllBuyer";
            this.mtbtnAllBuyer.Size = new System.Drawing.Size(156, 23);
            this.mtbtnAllBuyer.TabIndex = 1;
            this.mtbtnAllBuyer.Text = "All Buyer";
            this.mtbtnAllBuyer.UseSelectable = true;
            this.mtbtnAllBuyer.Click += new System.EventHandler(this.mtbtnAllBuyer_Click);
            // 
            // metroPanel1
            // 
            this.metroPanel1.Controls.Add(this.txtRole);
            this.metroPanel1.Controls.Add(this.txtUserName);
            this.metroPanel1.Controls.Add(this.txtPhone);
            this.metroPanel1.Controls.Add(this.mtlblRole);
            this.metroPanel1.Controls.Add(this.mtlblUsername);
            this.metroPanel1.Controls.Add(this.mtlblPhone);
            this.metroPanel1.Controls.Add(this.txtEmail);
            this.metroPanel1.Controls.Add(this.txtName);
            this.metroPanel1.Controls.Add(this.txtId);
            this.metroPanel1.Controls.Add(this.mtlblEmail);
            this.metroPanel1.Controls.Add(this.mtlblName);
            this.metroPanel1.Controls.Add(this.mtlblId);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(23, 81);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(586, 192);
            this.metroPanel1.TabIndex = 2;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // txtRole
            // 
            this.txtRole.Location = new System.Drawing.Point(336, 154);
            this.txtRole.Name = "txtRole";
            this.txtRole.Size = new System.Drawing.Size(120, 23);
            this.txtRole.TabIndex = 13;
            // 
            // txtUserName
            // 
            this.txtUserName.Location = new System.Drawing.Point(336, 84);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(120, 23);
            this.txtUserName.TabIndex = 12;
            // 
            // txtPhone
            // 
            this.txtPhone.Location = new System.Drawing.Point(319, 12);
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(137, 23);
            this.txtPhone.TabIndex = 11;
            // 
            // mtlblRole
            // 
            this.mtlblRole.AutoSize = true;
            this.mtlblRole.Location = new System.Drawing.Point(259, 154);
            this.mtlblRole.Name = "mtlblRole";
            this.mtlblRole.Size = new System.Drawing.Size(41, 19);
            this.mtlblRole.TabIndex = 10;
            this.mtlblRole.Text = "ROLE";
            // 
            // mtlblUsername
            // 
            this.mtlblUsername.AutoSize = true;
            this.mtlblUsername.Location = new System.Drawing.Point(259, 88);
            this.mtlblUsername.Name = "mtlblUsername";
            this.mtlblUsername.Size = new System.Drawing.Size(71, 19);
            this.mtlblUsername.TabIndex = 9;
            this.mtlblUsername.Text = "UserName";
            // 
            // mtlblPhone
            // 
            this.mtlblPhone.AutoSize = true;
            this.mtlblPhone.Location = new System.Drawing.Point(259, 16);
            this.mtlblPhone.Name = "mtlblPhone";
            this.mtlblPhone.Size = new System.Drawing.Size(54, 19);
            this.mtlblPhone.TabIndex = 8;
            this.mtlblPhone.Text = "PHONE";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(71, 154);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(104, 23);
            this.txtEmail.TabIndex = 7;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(68, 84);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(104, 23);
            this.txtName.TabIndex = 6;
            // 
            // txtId
            // 
            this.txtId.Location = new System.Drawing.Point(68, 11);
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(69, 23);
            this.txtId.TabIndex = 5;
            // 
            // mtlblEmail
            // 
            this.mtlblEmail.AutoSize = true;
            this.mtlblEmail.Location = new System.Drawing.Point(18, 154);
            this.mtlblEmail.Name = "mtlblEmail";
            this.mtlblEmail.Size = new System.Drawing.Size(47, 19);
            this.mtlblEmail.TabIndex = 4;
            this.mtlblEmail.Text = "E-mail";
            // 
            // mtlblName
            // 
            this.mtlblName.AutoSize = true;
            this.mtlblName.Location = new System.Drawing.Point(18, 88);
            this.mtlblName.Name = "mtlblName";
            this.mtlblName.Size = new System.Drawing.Size(47, 19);
            this.mtlblName.TabIndex = 3;
            this.mtlblName.Text = "NAME";
            // 
            // mtlblId
            // 
            this.mtlblId.AutoSize = true;
            this.mtlblId.Location = new System.Drawing.Point(18, 16);
            this.mtlblId.Name = "mtlblId";
            this.mtlblId.Size = new System.Drawing.Size(21, 19);
            this.mtlblId.TabIndex = 2;
            this.mtlblId.Text = "ID";
            // 
            // mtbtnSearchBuyer
            // 
            this.mtbtnSearchBuyer.Location = new System.Drawing.Point(615, 52);
            this.mtbtnSearchBuyer.Name = "mtbtnSearchBuyer";
            this.mtbtnSearchBuyer.Size = new System.Drawing.Size(156, 23);
            this.mtbtnSearchBuyer.TabIndex = 3;
            this.mtbtnSearchBuyer.Text = "Search Buyer";
            this.mtbtnSearchBuyer.UseSelectable = true;
            this.mtbtnSearchBuyer.Click += new System.EventHandler(this.mtbtnSearchBuyer_Click);
            // 
            // txtSearchUname
            // 
            this.txtSearchUname.Location = new System.Drawing.Point(355, 52);
            this.txtSearchUname.Name = "txtSearchUname";
            this.txtSearchUname.PlaceholderText = "Search by Username";
            this.txtSearchUname.Size = new System.Drawing.Size(235, 23);
            this.txtSearchUname.TabIndex = 4;
            // 
            // mtbtnDelete
            // 
            this.mtbtnDelete.Location = new System.Drawing.Point(618, 165);
            this.mtbtnDelete.Name = "mtbtnDelete";
            this.mtbtnDelete.Size = new System.Drawing.Size(156, 23);
            this.mtbtnDelete.TabIndex = 5;
            this.mtbtnDelete.Text = "Delete Buyer";
            this.mtbtnDelete.UseSelectable = true;
            this.mtbtnDelete.Click += new System.EventHandler(this.mtbtnDelete_Click);
            // 
            // mtbtnBack
            // 
            this.mtbtnBack.Location = new System.Drawing.Point(699, 260);
            this.mtbtnBack.Name = "mtbtnBack";
            this.mtbtnBack.Size = new System.Drawing.Size(75, 23);
            this.mtbtnBack.TabIndex = 6;
            this.mtbtnBack.Text = "Back";
            this.mtbtnBack.UseSelectable = true;
            this.mtbtnBack.Click += new System.EventHandler(this.mtbtnBack_Click);
            // 
            // mtbtnClearContent
            // 
            this.mtbtnClearContent.Location = new System.Drawing.Point(618, 220);
            this.mtbtnClearContent.Name = "mtbtnClearContent";
            this.mtbtnClearContent.Size = new System.Drawing.Size(156, 25);
            this.mtbtnClearContent.TabIndex = 7;
            this.mtbtnClearContent.Text = "Clear Content";
            this.mtbtnClearContent.UseSelectable = true;
            this.mtbtnClearContent.Click += new System.EventHandler(this.mtbtnClearContent_Click);
            // 
            // BuyerDelete
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(794, 583);
            this.Controls.Add(this.mtbtnClearContent);
            this.Controls.Add(this.mtbtnBack);
            this.Controls.Add(this.mtbtnDelete);
            this.Controls.Add(this.txtSearchUname);
            this.Controls.Add(this.mtbtnSearchBuyer);
            this.Controls.Add(this.metroPanel1);
            this.Controls.Add(this.mtbtnAllBuyer);
            this.Controls.Add(this.panel1);
            this.Name = "BuyerDelete";
            this.Text = "BuyerDelete";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvBuyerDelete)).EndInit();
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dgvBuyerDelete;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn NAME;
        private System.Windows.Forms.DataGridViewTextBoxColumn EMAIL;
        private System.Windows.Forms.DataGridViewTextBoxColumn PHONE;
        private System.Windows.Forms.DataGridViewTextBoxColumn USERNAME;
        private System.Windows.Forms.DataGridViewTextBoxColumn ROLE;
        private MetroFramework.Controls.MetroButton mtbtnAllBuyer;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private MetroFramework.Controls.MetroButton mtbtnSearchBuyer;
        private System.Windows.Forms.TextBox txtSearchUname;
        private MetroFramework.Controls.MetroLabel mtlblEmail;
        private MetroFramework.Controls.MetroLabel mtlblName;
        private MetroFramework.Controls.MetroLabel mtlblId;
        private System.Windows.Forms.TextBox txtId;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtRole;
        private System.Windows.Forms.TextBox txtUserName;
        private System.Windows.Forms.TextBox txtPhone;
        private MetroFramework.Controls.MetroLabel mtlblRole;
        private MetroFramework.Controls.MetroLabel mtlblUsername;
        private MetroFramework.Controls.MetroLabel mtlblPhone;
        private System.Windows.Forms.TextBox txtEmail;
        private MetroFramework.Controls.MetroButton mtbtnDelete;
        private MetroFramework.Controls.MetroButton mtbtnBack;
        private MetroFramework.Controls.MetroButton mtbtnClearContent;
    }
}