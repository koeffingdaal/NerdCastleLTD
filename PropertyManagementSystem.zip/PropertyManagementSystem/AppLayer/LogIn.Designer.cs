﻿
namespace PropertyManagementSystem.AppLayer
{
    partial class LogIn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.mtbtnRegistration = new MetroFramework.Controls.MetroButton();
            this.mtbtnLogIn = new MetroFramework.Controls.MetroButton();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.mtlblPassword = new MetroFramework.Controls.MetroLabel();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.mtlblName = new MetroFramework.Controls.MetroLabel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.mtbtnRegistration);
            this.panel1.Controls.Add(this.mtbtnLogIn);
            this.panel1.Controls.Add(this.txtPassword);
            this.panel1.Controls.Add(this.mtlblPassword);
            this.panel1.Controls.Add(this.txtUserName);
            this.panel1.Controls.Add(this.mtlblName);
            this.panel1.Location = new System.Drawing.Point(94, 165);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(475, 318);
            this.panel1.TabIndex = 0;
            // 
            // mtbtnRegistration
            // 
            this.mtbtnRegistration.Location = new System.Drawing.Point(311, 252);
            this.mtbtnRegistration.Name = "mtbtnRegistration";
            this.mtbtnRegistration.Size = new System.Drawing.Size(106, 23);
            this.mtbtnRegistration.TabIndex = 5;
            this.mtbtnRegistration.Text = "Registration";
            this.mtbtnRegistration.UseSelectable = true;
            this.mtbtnRegistration.Click += new System.EventHandler(this.mtbtnRegistration_Click);
            // 
            // mtbtnLogIn
            // 
            this.mtbtnLogIn.Location = new System.Drawing.Point(159, 252);
            this.mtbtnLogIn.Name = "mtbtnLogIn";
            this.mtbtnLogIn.Size = new System.Drawing.Size(106, 23);
            this.mtbtnLogIn.TabIndex = 4;
            this.mtbtnLogIn.Text = "Log In";
            this.mtbtnLogIn.UseSelectable = true;
            this.mtbtnLogIn.Click += new System.EventHandler(this.mtbtnLogIn_Click);
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(159, 175);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(229, 23);
            this.txtPassword.TabIndex = 3;
            // 
            // mtlblPassword
            // 
            this.mtlblPassword.AutoSize = true;
            this.mtlblPassword.Location = new System.Drawing.Point(74, 179);
            this.mtlblPassword.Name = "mtlblPassword";
            this.mtlblPassword.Size = new System.Drawing.Size(63, 19);
            this.mtlblPassword.TabIndex = 2;
            this.mtlblPassword.Text = "Password";
            // 
            // txtUserName
            // 
            this.txtUserName.Location = new System.Drawing.Point(159, 116);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(229, 23);
            this.txtUserName.TabIndex = 1;
            // 
            // mtlblName
            // 
            this.mtlblName.AutoSize = true;
            this.mtlblName.Location = new System.Drawing.Point(74, 120);
            this.mtlblName.Name = "mtlblName";
            this.mtlblName.Size = new System.Drawing.Size(75, 19);
            this.mtlblName.TabIndex = 0;
            this.mtlblName.Text = "User Name";
            // 
            // LogIn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(653, 565);
            this.Controls.Add(this.panel1);
            this.Name = "LogIn";
            this.Text = "LogIn";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private MetroFramework.Controls.MetroButton mtbtnLogIn;
        private System.Windows.Forms.TextBox txtPassword;
        private MetroFramework.Controls.MetroLabel mtlblPassword;
        private System.Windows.Forms.TextBox txtUserName;
        private MetroFramework.Controls.MetroLabel mtlblName;
        private MetroFramework.Controls.MetroButton mtbtnRegistration;
    }
}