﻿
namespace PropertyManagementSystem.AppLayer
{
    partial class DeleteOpenSpace
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.dgvDeleteOpenSpace = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.APPID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AREA = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DISTRICT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PRICE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SIZE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ISSUEDATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.metroPanel2 = new MetroFramework.Controls.MetroPanel();
            this.mtlblId = new MetroFramework.Controls.MetroLabel();
            this.mtlblAppId = new MetroFramework.Controls.MetroLabel();
            this.mtlblDistrict = new MetroFramework.Controls.MetroLabel();
            this.mtlblPrice = new MetroFramework.Controls.MetroLabel();
            this.mtlblArea = new MetroFramework.Controls.MetroLabel();
            this.txtId = new System.Windows.Forms.TextBox();
            this.txtArea = new System.Windows.Forms.TextBox();
            this.txtAppId = new System.Windows.Forms.TextBox();
            this.txtSearchAppId = new System.Windows.Forms.TextBox();
            this.txtDistrict = new System.Windows.Forms.TextBox();
            this.mtlblSize = new MetroFramework.Controls.MetroLabel();
            this.mtlblIssueDate = new MetroFramework.Controls.MetroLabel();
            this.txtSize = new System.Windows.Forms.TextBox();
            this.mtdtIssueDate = new MetroFramework.Controls.MetroDateTime();
            this.mtbtnDelete = new MetroFramework.Controls.MetroButton();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.mtbtnSearch = new MetroFramework.Controls.MetroButton();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDeleteOpenSpace)).BeginInit();
            this.metroPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // metroPanel1
            // 
            this.metroPanel1.Controls.Add(this.dgvDeleteOpenSpace);
            this.metroPanel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(20, 323);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(715, 239);
            this.metroPanel1.TabIndex = 0;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // dgvDeleteOpenSpace
            // 
            this.dgvDeleteOpenSpace.AllowUserToAddRows = false;
            this.dgvDeleteOpenSpace.AllowUserToDeleteRows = false;
            this.dgvDeleteOpenSpace.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDeleteOpenSpace.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.APPID,
            this.AREA,
            this.DISTRICT,
            this.PRICE,
            this.SIZE,
            this.ISSUEDATE});
            this.dgvDeleteOpenSpace.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDeleteOpenSpace.Location = new System.Drawing.Point(0, 0);
            this.dgvDeleteOpenSpace.Name = "dgvDeleteOpenSpace";
            this.dgvDeleteOpenSpace.ReadOnly = true;
            this.dgvDeleteOpenSpace.RowTemplate.Height = 25;
            this.dgvDeleteOpenSpace.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDeleteOpenSpace.Size = new System.Drawing.Size(715, 239);
            this.dgvDeleteOpenSpace.TabIndex = 2;
            this.dgvDeleteOpenSpace.DoubleClick += new System.EventHandler(this.dgvDeleteOpenSpace_DoubleClick);
            // 
            // ID
            // 
            this.ID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ID.DataPropertyName = "Id";
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            // 
            // APPID
            // 
            this.APPID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.APPID.DataPropertyName = "AppId";
            this.APPID.HeaderText = "APPID";
            this.APPID.Name = "APPID";
            this.APPID.ReadOnly = true;
            // 
            // AREA
            // 
            this.AREA.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.AREA.DataPropertyName = "Area";
            this.AREA.HeaderText = "AREA";
            this.AREA.Name = "AREA";
            this.AREA.ReadOnly = true;
            // 
            // DISTRICT
            // 
            this.DISTRICT.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.DISTRICT.DataPropertyName = "District";
            this.DISTRICT.HeaderText = "DISTRICT";
            this.DISTRICT.Name = "DISTRICT";
            this.DISTRICT.ReadOnly = true;
            // 
            // PRICE
            // 
            this.PRICE.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.PRICE.DataPropertyName = "Price";
            this.PRICE.HeaderText = "PRICE";
            this.PRICE.Name = "PRICE";
            this.PRICE.ReadOnly = true;
            // 
            // SIZE
            // 
            this.SIZE.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.SIZE.DataPropertyName = "Size";
            this.SIZE.HeaderText = "SIZE";
            this.SIZE.Name = "SIZE";
            this.SIZE.ReadOnly = true;
            // 
            // ISSUEDATE
            // 
            this.ISSUEDATE.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ISSUEDATE.DataPropertyName = "IssueDate";
            this.ISSUEDATE.HeaderText = "ISSUEDATE";
            this.ISSUEDATE.Name = "ISSUEDATE";
            this.ISSUEDATE.ReadOnly = true;
            // 
            // metroPanel2
            // 
            this.metroPanel2.Controls.Add(this.txtPrice);
            this.metroPanel2.Controls.Add(this.mtdtIssueDate);
            this.metroPanel2.Controls.Add(this.txtSize);
            this.metroPanel2.Controls.Add(this.mtlblIssueDate);
            this.metroPanel2.Controls.Add(this.mtlblSize);
            this.metroPanel2.Controls.Add(this.txtDistrict);
            this.metroPanel2.Controls.Add(this.txtAppId);
            this.metroPanel2.Controls.Add(this.txtArea);
            this.metroPanel2.Controls.Add(this.txtId);
            this.metroPanel2.Controls.Add(this.mtlblArea);
            this.metroPanel2.Controls.Add(this.mtlblPrice);
            this.metroPanel2.Controls.Add(this.mtlblDistrict);
            this.metroPanel2.Controls.Add(this.mtlblAppId);
            this.metroPanel2.Controls.Add(this.mtlblId);
            this.metroPanel2.HorizontalScrollbarBarColor = true;
            this.metroPanel2.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel2.HorizontalScrollbarSize = 10;
            this.metroPanel2.Location = new System.Drawing.Point(23, 63);
            this.metroPanel2.Name = "metroPanel2";
            this.metroPanel2.Size = new System.Drawing.Size(535, 254);
            this.metroPanel2.TabIndex = 1;
            this.metroPanel2.VerticalScrollbarBarColor = true;
            this.metroPanel2.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel2.VerticalScrollbarSize = 10;
            // 
            // mtlblId
            // 
            this.mtlblId.AutoSize = true;
            this.mtlblId.Location = new System.Drawing.Point(15, 23);
            this.mtlblId.Name = "mtlblId";
            this.mtlblId.Size = new System.Drawing.Size(21, 19);
            this.mtlblId.TabIndex = 2;
            this.mtlblId.Text = "ID";
            // 
            // mtlblAppId
            // 
            this.mtlblAppId.AutoSize = true;
            this.mtlblAppId.Location = new System.Drawing.Point(15, 74);
            this.mtlblAppId.Name = "mtlblAppId";
            this.mtlblAppId.Size = new System.Drawing.Size(50, 19);
            this.mtlblAppId.TabIndex = 3;
            this.mtlblAppId.Text = "App ID";
            // 
            // mtlblDistrict
            // 
            this.mtlblDistrict.AutoSize = true;
            this.mtlblDistrict.Location = new System.Drawing.Point(15, 183);
            this.mtlblDistrict.Name = "mtlblDistrict";
            this.mtlblDistrict.Size = new System.Drawing.Size(48, 19);
            this.mtlblDistrict.TabIndex = 4;
            this.mtlblDistrict.Text = "District";
            // 
            // mtlblPrice
            // 
            this.mtlblPrice.AutoSize = true;
            this.mtlblPrice.Location = new System.Drawing.Point(245, 23);
            this.mtlblPrice.Name = "mtlblPrice";
            this.mtlblPrice.Size = new System.Drawing.Size(38, 19);
            this.mtlblPrice.TabIndex = 5;
            this.mtlblPrice.Text = "Price";
            // 
            // mtlblArea
            // 
            this.mtlblArea.AutoSize = true;
            this.mtlblArea.Location = new System.Drawing.Point(15, 131);
            this.mtlblArea.Name = "mtlblArea";
            this.mtlblArea.Size = new System.Drawing.Size(42, 19);
            this.mtlblArea.TabIndex = 6;
            this.mtlblArea.Text = "AREA";
            // 
            // txtId
            // 
            this.txtId.Location = new System.Drawing.Point(86, 23);
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(115, 23);
            this.txtId.TabIndex = 7;
            // 
            // txtArea
            // 
            this.txtArea.Location = new System.Drawing.Point(86, 127);
            this.txtArea.Name = "txtArea";
            this.txtArea.Size = new System.Drawing.Size(115, 23);
            this.txtArea.TabIndex = 8;
            // 
            // txtAppId
            // 
            this.txtAppId.Location = new System.Drawing.Point(86, 70);
            this.txtAppId.Name = "txtAppId";
            this.txtAppId.Size = new System.Drawing.Size(115, 23);
            this.txtAppId.TabIndex = 9;
            // 
            // txtSearchAppId
            // 
            this.txtSearchAppId.Location = new System.Drawing.Point(412, 34);
            this.txtSearchAppId.Name = "txtSearchAppId";
            this.txtSearchAppId.PlaceholderText = "Search By AppId";
            this.txtSearchAppId.Size = new System.Drawing.Size(146, 23);
            this.txtSearchAppId.TabIndex = 10;
            this.txtSearchAppId.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // txtDistrict
            // 
            this.txtDistrict.Location = new System.Drawing.Point(86, 183);
            this.txtDistrict.Name = "txtDistrict";
            this.txtDistrict.Size = new System.Drawing.Size(115, 23);
            this.txtDistrict.TabIndex = 11;
            // 
            // mtlblSize
            // 
            this.mtlblSize.AutoSize = true;
            this.mtlblSize.Location = new System.Drawing.Point(245, 74);
            this.mtlblSize.Name = "mtlblSize";
            this.mtlblSize.Size = new System.Drawing.Size(32, 19);
            this.mtlblSize.TabIndex = 12;
            this.mtlblSize.Text = "Size";
            // 
            // mtlblIssueDate
            // 
            this.mtlblIssueDate.AutoSize = true;
            this.mtlblIssueDate.Location = new System.Drawing.Point(245, 127);
            this.mtlblIssueDate.Name = "mtlblIssueDate";
            this.mtlblIssueDate.Size = new System.Drawing.Size(67, 19);
            this.mtlblIssueDate.TabIndex = 13;
            this.mtlblIssueDate.Text = "Issue Date";
            // 
            // txtSize
            // 
            this.txtSize.Location = new System.Drawing.Point(310, 70);
            this.txtSize.Name = "txtSize";
            this.txtSize.Size = new System.Drawing.Size(115, 23);
            this.txtSize.TabIndex = 14;
            // 
            // mtdtIssueDate
            // 
            this.mtdtIssueDate.Location = new System.Drawing.Point(318, 121);
            this.mtdtIssueDate.MinimumSize = new System.Drawing.Size(0, 29);
            this.mtdtIssueDate.Name = "mtdtIssueDate";
            this.mtdtIssueDate.Size = new System.Drawing.Size(200, 29);
            this.mtdtIssueDate.TabIndex = 16;
            // 
            // mtbtnDelete
            // 
            this.mtbtnDelete.Location = new System.Drawing.Point(575, 294);
            this.mtbtnDelete.Name = "mtbtnDelete";
            this.mtbtnDelete.Size = new System.Drawing.Size(157, 23);
            this.mtbtnDelete.TabIndex = 17;
            this.mtbtnDelete.Text = "Delete";
            this.mtbtnDelete.UseSelectable = true;
            this.mtbtnDelete.Click += new System.EventHandler(this.mtbtnDelete_Click);
            // 
            // txtPrice
            // 
            this.txtPrice.Location = new System.Drawing.Point(289, 23);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(100, 23);
            this.txtPrice.TabIndex = 17;
            // 
            // mtbtnSearch
            // 
            this.mtbtnSearch.Location = new System.Drawing.Point(575, 34);
            this.mtbtnSearch.Name = "mtbtnSearch";
            this.mtbtnSearch.Size = new System.Drawing.Size(157, 23);
            this.mtbtnSearch.TabIndex = 18;
            this.mtbtnSearch.Text = "Search";
            this.mtbtnSearch.UseSelectable = true;
            // 
            // DeleteOpenSpace
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(755, 582);
            this.Controls.Add(this.mtbtnSearch);
            this.Controls.Add(this.mtbtnDelete);
            this.Controls.Add(this.metroPanel2);
            this.Controls.Add(this.metroPanel1);
            this.Controls.Add(this.txtSearchAppId);
            this.Name = "DeleteOpenSpace";
            this.Text = "Delete OpenSpace";
            this.metroPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDeleteOpenSpace)).EndInit();
            this.metroPanel2.ResumeLayout(false);
            this.metroPanel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroPanel metroPanel1;
        private System.Windows.Forms.DataGridView dgvDeleteOpenSpace;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn APPID;
        private System.Windows.Forms.DataGridViewTextBoxColumn AREA;
        private System.Windows.Forms.DataGridViewTextBoxColumn DISTRICT;
        private System.Windows.Forms.DataGridViewTextBoxColumn PRICE;
        private System.Windows.Forms.DataGridViewTextBoxColumn SIZE;
        private System.Windows.Forms.DataGridViewTextBoxColumn ISSUEDATE;
        private MetroFramework.Controls.MetroPanel metroPanel2;
        private System.Windows.Forms.TextBox txtSearchAppId;
        private System.Windows.Forms.TextBox txtAppId;
        private System.Windows.Forms.TextBox txtArea;
        private System.Windows.Forms.TextBox txtId;
        private MetroFramework.Controls.MetroLabel mtlblArea;
        private MetroFramework.Controls.MetroLabel mtlblPrice;
        private MetroFramework.Controls.MetroLabel mtlblDistrict;
        private MetroFramework.Controls.MetroLabel mtlblAppId;
        private MetroFramework.Controls.MetroLabel mtlblId;
        private MetroFramework.Controls.MetroLabel mtlblIssueDate;
        private MetroFramework.Controls.MetroLabel mtlblSize;
        private System.Windows.Forms.TextBox txtDistrict;
        private MetroFramework.Controls.MetroDateTime mtdtIssueDate;
        private System.Windows.Forms.TextBox txtSize;
        private MetroFramework.Controls.MetroButton mtbtnDelete;
        private System.Windows.Forms.TextBox txtPrice;
        private MetroFramework.Controls.MetroButton mtbtnSearch;
    }
}