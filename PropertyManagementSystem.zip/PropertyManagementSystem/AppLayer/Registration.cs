﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using PropertyManagementSystem.EntityLayer;
using PropertyManagementSystem.AppLayer;
using PropertyManagementSystem.RepositoryLayer;
using PropertyManagementSystem.ValidationLayer;


namespace PropertyManagementSystem.AppLayer
{
    public partial class Registration : MetroFramework.Forms.MetroForm
    {

        
        public Registration()
        {
            InitializeComponent();
        }

        private void mtlblName_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void mtbtnRegistration_Click(object sender, EventArgs e)
        {
            UserRegistrationEntity ure = new UserRegistrationEntity();
            RegistrationRepository regRepo = new RegistrationRepository();
            RegistrationValidation regVal = new RegistrationValidation();
            ure.Name = this.txtName.Text;
            ure.Password = this.txtPassword.Text;
            ure.Email = this.txtEmail.Text;
            ure.Phone = this.txtPhone.Text;
            ure.UserName = this.txtUserName.Text;


            if (this.mtrbBuyer.Checked)
            {

                ure.Role = "Buyer";

            }
            else if(this.mtrbSeller.Checked)
            {
                ure.Role = "Seller";
            }

            if (regVal.IsEmpty(ure))
            {
                regRepo.UserRegistration(ure);
                MessageBox.Show("Registration Successfull");
                LogIn logIn = new LogIn();
                this.Hide();
                logIn.Show();
            }
            else
            {
                MessageBox.Show("Please, Submit all Your info");
            }

            
        }

        private void mtbtnClear_Click(object sender, EventArgs e)
        {
            ClearContent();

        }

        public void ClearContent()
        {
            this.txtName.Text = "";
            this.txtUserName.Text = "";
            this.txtPassword.Text = "";
            this.txtEmail.Text = "";
            this.txtPhone.Text = "";
            this.mtrbSeller.Checked = false;
            this.mtrbBuyer.Checked = false;
        }
    }
}
