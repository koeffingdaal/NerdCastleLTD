﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using PropertyManagementSystem.RepositoryLayer;
using PropertyManagementSystem.EntityLayer;

namespace PropertyManagementSystem.AppLayer
{
    public partial class UpdateOpenSpace : MetroFramework.Forms.MetroForm
    {
        public UpdateOpenSpace()
        {
            InitializeComponent();
            PopulatedGridView();
          
        }

        public void PopulatedGridView()
        {
            OpenSpaceRepo osr = new OpenSpaceRepo();
            this.dgvUpdateOpenSpace.AutoGenerateColumns = false;
            this.dgvUpdateOpenSpace.DataSource = osr.AllOpenSpace();
        }

        private void metroPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void mtlblIssueDate_Click(object sender, EventArgs e)
        {

        }

        private void dgvUpdateOpenSpace_DoubleClick(object sender, EventArgs e)
        {
            this.txtId.Text = this.dgvUpdateOpenSpace.CurrentRow.Cells["Id"].Value.ToString();
            this.txtAppId.Text = this.dgvUpdateOpenSpace.CurrentRow.Cells["AppId"].Value.ToString();
            this.txtArea.Text = this.dgvUpdateOpenSpace.CurrentRow.Cells["Area"].Value.ToString();
            this.txtDistrict.Text = this.dgvUpdateOpenSpace.CurrentRow.Cells["District"].Value.ToString();
            this.txtPrice.Text = this.dgvUpdateOpenSpace.CurrentRow.Cells["Price"].Value.ToString();
            this.txtSize.Text = this.dgvUpdateOpenSpace.CurrentRow.Cells["Size"].Value.ToString();
            this.mtdtIssueDate.Text = this.dgvUpdateOpenSpace.CurrentRow.Cells["IssueDate"].Value.ToString();

            this.txtAppId.ReadOnly = true;
            this.txtId.ReadOnly = true;
        }

        private void mtbtnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                OpenUpdateEntity oue = new OpenUpdateEntity();
                oue.AppId = this.txtAppId.Text;
                oue.Area = this.txtArea.Text;
                oue.District = this.txtDistrict.Text;
                oue.IssueDate = this.mtdtIssueDate.Value;
                oue.Price = Convert.ToDouble(txtPrice.Text);
                oue.Size = Convert.ToInt32(txtSize.Text);

                OpenSpaceRepo osr = new OpenSpaceRepo();
                //osr.UpdateOpenSpace(osr);
                osr.UpdateOpenSpace(oue.Area,oue.District,oue.Price,oue.Size,oue.IssueDate,oue.AppId);

                MessageBox.Show("Updated");

                PopulatedGridView();
                
            }
            catch(Exception exc)
            {
                MessageBox.Show("Update Failed");
            }
        }

        private void mtbtnClear_Click(object sender, EventArgs e)
        {
            ClearContent();
        }

        public void ClearContent()
        {
            this.txtAppId.Clear();
            this.txtId.Clear();
            this.txtArea.Clear();
            this.txtDistrict.Clear();
            this.txtPrice.Clear();
            this.txtSize.Clear();
            this.mtdtIssueDate.Checked = false;
        }

        private void mtbtnSearch_Click(object sender, EventArgs e)
        {
            OpenSearchAppIdEntity searchAppId = new OpenSearchAppIdEntity();
            

            OpenSpaceRepo osr = new OpenSpaceRepo();
            searchAppId.SearchAppId = this.txtSearchAppId.Text;
            this.dgvUpdateOpenSpace.AutoGenerateColumns = false;

            this.dgvUpdateOpenSpace.DataSource = osr.SearchAppId(searchAppId.SearchAppId);

            
            
        }
    }
}
