﻿
namespace PropertyManagementSystem.AppLayer
{
    partial class UpdateOpenSpace
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mtpnlUpdateOpenSpace = new MetroFramework.Controls.MetroPanel();
            this.dgvUpdateOpenSpace = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.APPID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AREA = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DISTRICT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ISSUEDATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SIZE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PRICE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.mtdtIssueDate = new MetroFramework.Controls.MetroDateTime();
            this.mtlblIssueDate = new MetroFramework.Controls.MetroLabel();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.mtlblPrice = new MetroFramework.Controls.MetroLabel();
            this.txtSize = new System.Windows.Forms.TextBox();
            this.mtlblSize = new MetroFramework.Controls.MetroLabel();
            this.txtDistrict = new System.Windows.Forms.TextBox();
            this.mtlblDistrict = new MetroFramework.Controls.MetroLabel();
            this.txtArea = new System.Windows.Forms.TextBox();
            this.mtlblArea = new MetroFramework.Controls.MetroLabel();
            this.txtAppId = new System.Windows.Forms.TextBox();
            this.mtlblAppId = new MetroFramework.Controls.MetroLabel();
            this.txtId = new System.Windows.Forms.TextBox();
            this.mtlblId = new MetroFramework.Controls.MetroLabel();
            this.mtbtnUpdate = new MetroFramework.Controls.MetroButton();
            this.mtbtnClear = new MetroFramework.Controls.MetroButton();
            this.txtSearchAppId = new System.Windows.Forms.TextBox();
            this.mtbtnSearch = new MetroFramework.Controls.MetroButton();
            this.mtpnlUpdateOpenSpace.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUpdateOpenSpace)).BeginInit();
            this.metroPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // mtpnlUpdateOpenSpace
            // 
            this.mtpnlUpdateOpenSpace.Controls.Add(this.dgvUpdateOpenSpace);
            this.mtpnlUpdateOpenSpace.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.mtpnlUpdateOpenSpace.HorizontalScrollbarBarColor = true;
            this.mtpnlUpdateOpenSpace.HorizontalScrollbarHighlightOnWheel = false;
            this.mtpnlUpdateOpenSpace.HorizontalScrollbarSize = 10;
            this.mtpnlUpdateOpenSpace.Location = new System.Drawing.Point(20, 244);
            this.mtpnlUpdateOpenSpace.Name = "mtpnlUpdateOpenSpace";
            this.mtpnlUpdateOpenSpace.Size = new System.Drawing.Size(736, 264);
            this.mtpnlUpdateOpenSpace.TabIndex = 0;
            this.mtpnlUpdateOpenSpace.VerticalScrollbarBarColor = true;
            this.mtpnlUpdateOpenSpace.VerticalScrollbarHighlightOnWheel = false;
            this.mtpnlUpdateOpenSpace.VerticalScrollbarSize = 10;
            // 
            // dgvUpdateOpenSpace
            // 
            this.dgvUpdateOpenSpace.AllowUserToAddRows = false;
            this.dgvUpdateOpenSpace.AllowUserToDeleteRows = false;
            this.dgvUpdateOpenSpace.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvUpdateOpenSpace.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvUpdateOpenSpace.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.APPID,
            this.AREA,
            this.DISTRICT,
            this.ISSUEDATE,
            this.SIZE,
            this.PRICE});
            this.dgvUpdateOpenSpace.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvUpdateOpenSpace.Location = new System.Drawing.Point(0, 0);
            this.dgvUpdateOpenSpace.Name = "dgvUpdateOpenSpace";
            this.dgvUpdateOpenSpace.ReadOnly = true;
            this.dgvUpdateOpenSpace.RowTemplate.Height = 25;
            this.dgvUpdateOpenSpace.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvUpdateOpenSpace.Size = new System.Drawing.Size(736, 264);
            this.dgvUpdateOpenSpace.TabIndex = 1;
            this.dgvUpdateOpenSpace.DoubleClick += new System.EventHandler(this.dgvUpdateOpenSpace_DoubleClick);
            // 
            // ID
            // 
            this.ID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ID.DataPropertyName = "Id";
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            // 
            // APPID
            // 
            this.APPID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.APPID.DataPropertyName = "AppId";
            this.APPID.HeaderText = "APPID";
            this.APPID.Name = "APPID";
            this.APPID.ReadOnly = true;
            // 
            // AREA
            // 
            this.AREA.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.AREA.DataPropertyName = "Area";
            this.AREA.HeaderText = "AREA";
            this.AREA.Name = "AREA";
            this.AREA.ReadOnly = true;
            // 
            // DISTRICT
            // 
            this.DISTRICT.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.DISTRICT.DataPropertyName = "District";
            this.DISTRICT.HeaderText = "DISTRICT";
            this.DISTRICT.Name = "DISTRICT";
            this.DISTRICT.ReadOnly = true;
            // 
            // ISSUEDATE
            // 
            this.ISSUEDATE.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ISSUEDATE.DataPropertyName = "IssueDate";
            this.ISSUEDATE.HeaderText = "ISSUEDATE";
            this.ISSUEDATE.Name = "ISSUEDATE";
            this.ISSUEDATE.ReadOnly = true;
            // 
            // SIZE
            // 
            this.SIZE.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.SIZE.DataPropertyName = "Size";
            this.SIZE.HeaderText = "SIZE";
            this.SIZE.Name = "SIZE";
            this.SIZE.ReadOnly = true;
            // 
            // PRICE
            // 
            this.PRICE.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.PRICE.DataPropertyName = "Price";
            this.PRICE.HeaderText = "PRICE";
            this.PRICE.Name = "PRICE";
            this.PRICE.ReadOnly = true;
            // 
            // metroPanel1
            // 
            this.metroPanel1.Controls.Add(this.mtdtIssueDate);
            this.metroPanel1.Controls.Add(this.mtlblIssueDate);
            this.metroPanel1.Controls.Add(this.txtPrice);
            this.metroPanel1.Controls.Add(this.mtlblPrice);
            this.metroPanel1.Controls.Add(this.txtSize);
            this.metroPanel1.Controls.Add(this.mtlblSize);
            this.metroPanel1.Controls.Add(this.txtDistrict);
            this.metroPanel1.Controls.Add(this.mtlblDistrict);
            this.metroPanel1.Controls.Add(this.txtArea);
            this.metroPanel1.Controls.Add(this.mtlblArea);
            this.metroPanel1.Controls.Add(this.txtAppId);
            this.metroPanel1.Controls.Add(this.mtlblAppId);
            this.metroPanel1.Controls.Add(this.txtId);
            this.metroPanel1.Controls.Add(this.mtlblId);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(23, 63);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(510, 169);
            this.metroPanel1.TabIndex = 1;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            this.metroPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.metroPanel1_Paint);
            // 
            // mtdtIssueDate
            // 
            this.mtdtIssueDate.Location = new System.Drawing.Point(278, 121);
            this.mtdtIssueDate.MinimumSize = new System.Drawing.Size(0, 29);
            this.mtdtIssueDate.Name = "mtdtIssueDate";
            this.mtdtIssueDate.Size = new System.Drawing.Size(192, 29);
            this.mtdtIssueDate.TabIndex = 15;
            // 
            // mtlblIssueDate
            // 
            this.mtlblIssueDate.AutoSize = true;
            this.mtlblIssueDate.Location = new System.Drawing.Point(199, 131);
            this.mtlblIssueDate.Name = "mtlblIssueDate";
            this.mtlblIssueDate.Size = new System.Drawing.Size(67, 19);
            this.mtlblIssueDate.TabIndex = 14;
            this.mtlblIssueDate.Text = "Issue Date";
            this.mtlblIssueDate.Click += new System.EventHandler(this.mtlblIssueDate_Click);
            // 
            // txtPrice
            // 
            this.txtPrice.Location = new System.Drawing.Point(278, 75);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(108, 23);
            this.txtPrice.TabIndex = 13;
            // 
            // mtlblPrice
            // 
            this.mtlblPrice.AutoSize = true;
            this.mtlblPrice.Location = new System.Drawing.Point(228, 75);
            this.mtlblPrice.Name = "mtlblPrice";
            this.mtlblPrice.Size = new System.Drawing.Size(38, 19);
            this.mtlblPrice.TabIndex = 12;
            this.mtlblPrice.Text = "Price";
            // 
            // txtSize
            // 
            this.txtSize.Location = new System.Drawing.Point(278, 7);
            this.txtSize.Name = "txtSize";
            this.txtSize.Size = new System.Drawing.Size(108, 23);
            this.txtSize.TabIndex = 11;
            // 
            // mtlblSize
            // 
            this.mtlblSize.AutoSize = true;
            this.mtlblSize.Location = new System.Drawing.Point(228, 11);
            this.mtlblSize.Name = "mtlblSize";
            this.mtlblSize.Size = new System.Drawing.Size(32, 19);
            this.mtlblSize.TabIndex = 10;
            this.mtlblSize.Text = "Size";
            // 
            // txtDistrict
            // 
            this.txtDistrict.Location = new System.Drawing.Point(70, 141);
            this.txtDistrict.Name = "txtDistrict";
            this.txtDistrict.Size = new System.Drawing.Size(108, 23);
            this.txtDistrict.TabIndex = 9;
            // 
            // mtlblDistrict
            // 
            this.mtlblDistrict.AutoSize = true;
            this.mtlblDistrict.Location = new System.Drawing.Point(14, 141);
            this.mtlblDistrict.Name = "mtlblDistrict";
            this.mtlblDistrict.Size = new System.Drawing.Size(48, 19);
            this.mtlblDistrict.TabIndex = 8;
            this.mtlblDistrict.Text = "District";
            // 
            // txtArea
            // 
            this.txtArea.Location = new System.Drawing.Point(70, 98);
            this.txtArea.Name = "txtArea";
            this.txtArea.Size = new System.Drawing.Size(108, 23);
            this.txtArea.TabIndex = 7;
            // 
            // mtlblArea
            // 
            this.mtlblArea.AutoSize = true;
            this.mtlblArea.Location = new System.Drawing.Point(14, 102);
            this.mtlblArea.Name = "mtlblArea";
            this.mtlblArea.Size = new System.Drawing.Size(37, 19);
            this.mtlblArea.TabIndex = 6;
            this.mtlblArea.Text = "Area";
            // 
            // txtAppId
            // 
            this.txtAppId.Location = new System.Drawing.Point(70, 52);
            this.txtAppId.Name = "txtAppId";
            this.txtAppId.Size = new System.Drawing.Size(108, 23);
            this.txtAppId.TabIndex = 5;
            // 
            // mtlblAppId
            // 
            this.mtlblAppId.AutoSize = true;
            this.mtlblAppId.Location = new System.Drawing.Point(14, 56);
            this.mtlblAppId.Name = "mtlblAppId";
            this.mtlblAppId.Size = new System.Drawing.Size(50, 19);
            this.mtlblAppId.TabIndex = 4;
            this.mtlblAppId.Text = "App ID";
            // 
            // txtId
            // 
            this.txtId.Location = new System.Drawing.Point(70, 7);
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(108, 23);
            this.txtId.TabIndex = 3;
            // 
            // mtlblId
            // 
            this.mtlblId.AutoSize = true;
            this.mtlblId.Location = new System.Drawing.Point(14, 11);
            this.mtlblId.Name = "mtlblId";
            this.mtlblId.Size = new System.Drawing.Size(21, 19);
            this.mtlblId.TabIndex = 2;
            this.mtlblId.Text = "ID";
            // 
            // mtbtnUpdate
            // 
            this.mtbtnUpdate.Location = new System.Drawing.Point(554, 189);
            this.mtbtnUpdate.Name = "mtbtnUpdate";
            this.mtbtnUpdate.Size = new System.Drawing.Size(75, 38);
            this.mtbtnUpdate.TabIndex = 16;
            this.mtbtnUpdate.Text = "Update";
            this.mtbtnUpdate.UseSelectable = true;
            this.mtbtnUpdate.Click += new System.EventHandler(this.mtbtnUpdate_Click);
            // 
            // mtbtnClear
            // 
            this.mtbtnClear.Location = new System.Drawing.Point(659, 189);
            this.mtbtnClear.Name = "mtbtnClear";
            this.mtbtnClear.Size = new System.Drawing.Size(75, 38);
            this.mtbtnClear.TabIndex = 17;
            this.mtbtnClear.Text = "Clear";
            this.mtbtnClear.UseSelectable = true;
            this.mtbtnClear.Click += new System.EventHandler(this.mtbtnClear_Click);
            // 
            // txtSearchAppId
            // 
            this.txtSearchAppId.Location = new System.Drawing.Point(388, 30);
            this.txtSearchAppId.Name = "txtSearchAppId";
            this.txtSearchAppId.PlaceholderText = "Search By AppId";
            this.txtSearchAppId.Size = new System.Drawing.Size(241, 23);
            this.txtSearchAppId.TabIndex = 18;
            // 
            // mtbtnSearch
            // 
            this.mtbtnSearch.Location = new System.Drawing.Point(659, 30);
            this.mtbtnSearch.Name = "mtbtnSearch";
            this.mtbtnSearch.Size = new System.Drawing.Size(75, 23);
            this.mtbtnSearch.TabIndex = 19;
            this.mtbtnSearch.Text = "Search";
            this.mtbtnSearch.UseSelectable = true;
            this.mtbtnSearch.Click += new System.EventHandler(this.mtbtnSearch_Click);
            // 
            // UpdateOpenSpace
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(776, 528);
            this.Controls.Add(this.mtbtnSearch);
            this.Controls.Add(this.txtSearchAppId);
            this.Controls.Add(this.mtbtnClear);
            this.Controls.Add(this.mtbtnUpdate);
            this.Controls.Add(this.metroPanel1);
            this.Controls.Add(this.mtpnlUpdateOpenSpace);
            this.Name = "UpdateOpenSpace";
            this.Resizable = false;
            this.Text = "Update OpenSpace";
            this.mtpnlUpdateOpenSpace.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvUpdateOpenSpace)).EndInit();
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroPanel mtpnlUpdateOpenSpace;
        private System.Windows.Forms.DataGridView dgvUpdateOpenSpace;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn APPID;
        private System.Windows.Forms.DataGridViewTextBoxColumn AREA;
        private System.Windows.Forms.DataGridViewTextBoxColumn DISTRICT;
        private System.Windows.Forms.DataGridViewTextBoxColumn ISSUEDATE;
        private System.Windows.Forms.DataGridViewTextBoxColumn SIZE;
        private System.Windows.Forms.DataGridViewTextBoxColumn PRICE;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private System.Windows.Forms.TextBox txtSize;
        private MetroFramework.Controls.MetroLabel mtlblSize;
        private System.Windows.Forms.TextBox txtDistrict;
        private MetroFramework.Controls.MetroLabel mtlblDistrict;
        private System.Windows.Forms.TextBox txtArea;
        private MetroFramework.Controls.MetroLabel mtlblArea;
        private System.Windows.Forms.TextBox txtAppId;
        private MetroFramework.Controls.MetroLabel mtlblAppId;
        private System.Windows.Forms.TextBox txtId;
        private MetroFramework.Controls.MetroLabel mtlblId;
        private MetroFramework.Controls.MetroDateTime mtdtIssueDate;
        private MetroFramework.Controls.MetroLabel mtlblIssueDate;
        private System.Windows.Forms.TextBox txtPrice;
        private MetroFramework.Controls.MetroLabel mtlblPrice;
        private MetroFramework.Controls.MetroButton mtbtnUpdate;
        private MetroFramework.Controls.MetroButton mtbtnClear;
        private System.Windows.Forms.TextBox txtSearchAppId;
        private MetroFramework.Controls.MetroButton mtbtnSearch;
    }
}