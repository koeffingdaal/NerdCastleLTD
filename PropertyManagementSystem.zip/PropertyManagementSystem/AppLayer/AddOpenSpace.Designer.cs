﻿
namespace PropertyManagementSystem.AppLayer
{
    partial class AddOpenSpace
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.mtIssueDate = new MetroFramework.Controls.MetroDateTime();
            this.mtlblIssueDate = new MetroFramework.Controls.MetroLabel();
            this.mtbtnAddOpenSpace = new MetroFramework.Controls.MetroButton();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.mtlblPrice = new MetroFramework.Controls.MetroLabel();
            this.txtSize = new System.Windows.Forms.TextBox();
            this.mtlblSize = new MetroFramework.Controls.MetroLabel();
            this.txtDistrict = new System.Windows.Forms.TextBox();
            this.mtlblDistrict = new MetroFramework.Controls.MetroLabel();
            this.txtArea = new System.Windows.Forms.TextBox();
            this.mtlblArea = new MetroFramework.Controls.MetroLabel();
            this.txtAppId = new System.Windows.Forms.TextBox();
            this.mtlblAppId = new MetroFramework.Controls.MetroLabel();
            this.mtlblAddOpenSpace = new MetroFramework.Controls.MetroLabel();
            this.metroPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // metroPanel1
            // 
            this.metroPanel1.Controls.Add(this.mtIssueDate);
            this.metroPanel1.Controls.Add(this.mtlblIssueDate);
            this.metroPanel1.Controls.Add(this.mtbtnAddOpenSpace);
            this.metroPanel1.Controls.Add(this.txtPrice);
            this.metroPanel1.Controls.Add(this.mtlblPrice);
            this.metroPanel1.Controls.Add(this.txtSize);
            this.metroPanel1.Controls.Add(this.mtlblSize);
            this.metroPanel1.Controls.Add(this.txtDistrict);
            this.metroPanel1.Controls.Add(this.mtlblDistrict);
            this.metroPanel1.Controls.Add(this.txtArea);
            this.metroPanel1.Controls.Add(this.mtlblArea);
            this.metroPanel1.Controls.Add(this.txtAppId);
            this.metroPanel1.Controls.Add(this.mtlblAppId);
            this.metroPanel1.Controls.Add(this.mtlblAddOpenSpace);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(182, 63);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(369, 432);
            this.metroPanel1.TabIndex = 0;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // mtIssueDate
            // 
            this.mtIssueDate.Location = new System.Drawing.Point(98, 315);
            this.mtIssueDate.MinimumSize = new System.Drawing.Size(0, 29);
            this.mtIssueDate.Name = "mtIssueDate";
            this.mtIssueDate.Size = new System.Drawing.Size(191, 29);
            this.mtIssueDate.TabIndex = 15;
            // 
            // mtlblIssueDate
            // 
            this.mtlblIssueDate.AutoSize = true;
            this.mtlblIssueDate.Location = new System.Drawing.Point(21, 315);
            this.mtlblIssueDate.Name = "mtlblIssueDate";
            this.mtlblIssueDate.Size = new System.Drawing.Size(67, 19);
            this.mtlblIssueDate.TabIndex = 14;
            this.mtlblIssueDate.Text = "Issue Date";
            // 
            // mtbtnAddOpenSpace
            // 
            this.mtbtnAddOpenSpace.Location = new System.Drawing.Point(126, 383);
            this.mtbtnAddOpenSpace.Name = "mtbtnAddOpenSpace";
            this.mtbtnAddOpenSpace.Size = new System.Drawing.Size(109, 23);
            this.mtbtnAddOpenSpace.TabIndex = 13;
            this.mtbtnAddOpenSpace.Text = "Add";
            this.mtbtnAddOpenSpace.UseSelectable = true;
            this.mtbtnAddOpenSpace.Click += new System.EventHandler(this.metroButton1_Click);
            // 
            // txtPrice
            // 
            this.txtPrice.Location = new System.Drawing.Point(100, 208);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.PlaceholderText = "Price";
            this.txtPrice.Size = new System.Drawing.Size(191, 23);
            this.txtPrice.TabIndex = 12;
            // 
            // mtlblPrice
            // 
            this.mtlblPrice.AutoSize = true;
            this.mtlblPrice.Location = new System.Drawing.Point(21, 212);
            this.mtlblPrice.Name = "mtlblPrice";
            this.mtlblPrice.Size = new System.Drawing.Size(38, 19);
            this.mtlblPrice.TabIndex = 11;
            this.mtlblPrice.Text = "Price";
            // 
            // txtSize
            // 
            this.txtSize.Location = new System.Drawing.Point(100, 261);
            this.txtSize.Name = "txtSize";
            this.txtSize.PlaceholderText = "Size";
            this.txtSize.Size = new System.Drawing.Size(191, 23);
            this.txtSize.TabIndex = 10;
            // 
            // mtlblSize
            // 
            this.mtlblSize.AutoSize = true;
            this.mtlblSize.Location = new System.Drawing.Point(21, 265);
            this.mtlblSize.Name = "mtlblSize";
            this.mtlblSize.Size = new System.Drawing.Size(71, 19);
            this.mtlblSize.TabIndex = 9;
            this.mtlblSize.Text = "Space Size";
            // 
            // txtDistrict
            // 
            this.txtDistrict.Location = new System.Drawing.Point(100, 160);
            this.txtDistrict.Name = "txtDistrict";
            this.txtDistrict.PlaceholderText = "District";
            this.txtDistrict.Size = new System.Drawing.Size(191, 23);
            this.txtDistrict.TabIndex = 8;
            // 
            // mtlblDistrict
            // 
            this.mtlblDistrict.AutoSize = true;
            this.mtlblDistrict.Location = new System.Drawing.Point(20, 164);
            this.mtlblDistrict.Name = "mtlblDistrict";
            this.mtlblDistrict.Size = new System.Drawing.Size(48, 19);
            this.mtlblDistrict.TabIndex = 7;
            this.mtlblDistrict.Text = "District";
            // 
            // txtArea
            // 
            this.txtArea.Location = new System.Drawing.Point(100, 107);
            this.txtArea.Name = "txtArea";
            this.txtArea.PlaceholderText = "Area";
            this.txtArea.Size = new System.Drawing.Size(191, 23);
            this.txtArea.TabIndex = 6;
            // 
            // mtlblArea
            // 
            this.mtlblArea.AutoSize = true;
            this.mtlblArea.Location = new System.Drawing.Point(20, 111);
            this.mtlblArea.Name = "mtlblArea";
            this.mtlblArea.Size = new System.Drawing.Size(37, 19);
            this.mtlblArea.TabIndex = 5;
            this.mtlblArea.Text = "Area";
            // 
            // txtAppId
            // 
            this.txtAppId.Location = new System.Drawing.Point(100, 54);
            this.txtAppId.Name = "txtAppId";
            this.txtAppId.PlaceholderText = "App Id";
            this.txtAppId.Size = new System.Drawing.Size(191, 23);
            this.txtAppId.TabIndex = 4;
            // 
            // mtlblAppId
            // 
            this.mtlblAppId.AutoSize = true;
            this.mtlblAppId.Location = new System.Drawing.Point(20, 58);
            this.mtlblAppId.Name = "mtlblAppId";
            this.mtlblAppId.Size = new System.Drawing.Size(49, 19);
            this.mtlblAppId.TabIndex = 3;
            this.mtlblAppId.Text = "App Id";
            // 
            // mtlblAddOpenSpace
            // 
            this.mtlblAddOpenSpace.AutoSize = true;
            this.mtlblAddOpenSpace.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.mtlblAddOpenSpace.Location = new System.Drawing.Point(85, 10);
            this.mtlblAddOpenSpace.Name = "mtlblAddOpenSpace";
            this.mtlblAddOpenSpace.Size = new System.Drawing.Size(182, 19);
            this.mtlblAddOpenSpace.TabIndex = 2;
            this.mtlblAddOpenSpace.Text = "Add Open Space Information";
            // 
            // AddOpenSpace
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(723, 540);
            this.Controls.Add(this.metroPanel1);
            this.Name = "AddOpenSpace";
            this.Text = "Add OpenSpace";
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroPanel metroPanel1;
        private MetroFramework.Controls.MetroDateTime mtIssueDate;
        private MetroFramework.Controls.MetroLabel mtlblIssueDate;
        private MetroFramework.Controls.MetroButton mtbtnAddOpenSpace;
        private System.Windows.Forms.TextBox txtPrice;
        private MetroFramework.Controls.MetroLabel mtlblPrice;
        private System.Windows.Forms.TextBox txtSize;
        private MetroFramework.Controls.MetroLabel mtlblSize;
        private System.Windows.Forms.TextBox txtDistrict;
        private MetroFramework.Controls.MetroLabel mtlblDistrict;
        private System.Windows.Forms.TextBox txtArea;
        private MetroFramework.Controls.MetroLabel mtlblArea;
        private System.Windows.Forms.TextBox txtAppId;
        private MetroFramework.Controls.MetroLabel mtlblAppId;
        private MetroFramework.Controls.MetroLabel mtlblAddOpenSpace;
    }
}