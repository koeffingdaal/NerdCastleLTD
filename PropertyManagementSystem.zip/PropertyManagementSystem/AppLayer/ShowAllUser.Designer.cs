﻿
namespace PropertyManagementSystem.AppLayer
{
    partial class ShowAllUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.dgvMemberInfo = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EMAIL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PHONE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PASSWORD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.USERNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mtbtnShowAll = new MetroFramework.Controls.MetroButton();
            this.txtName = new System.Windows.Forms.TextBox();
            this.mtlblName = new MetroFramework.Controls.MetroLabel();
            this.mtlblEmail = new MetroFramework.Controls.MetroLabel();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.mtlblPassword = new MetroFramework.Controls.MetroLabel();
            this.mtlblPhone = new MetroFramework.Controls.MetroLabel();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.mtlblUserName = new MetroFramework.Controls.MetroLabel();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.metroPanel2 = new MetroFramework.Controls.MetroPanel();
            this.mtbtnDelete = new MetroFramework.Controls.MetroButton();
            this.mtbtnSave = new MetroFramework.Controls.MetroButton();
            this.txtSearchUname = new System.Windows.Forms.TextBox();
            this.mtbtnSearch = new MetroFramework.Controls.MetroButton();
            this.txtSearchRole = new System.Windows.Forms.TextBox();
            this.mtbtnSearchRole = new MetroFramework.Controls.MetroButton();
            this.mtbtnUpdate = new MetroFramework.Controls.MetroButton();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMemberInfo)).BeginInit();
            this.metroPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // metroPanel1
            // 
            this.metroPanel1.Controls.Add(this.dgvMemberInfo);
            this.metroPanel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(20, 290);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(760, 229);
            this.metroPanel1.TabIndex = 0;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // dgvMemberInfo
            // 
            this.dgvMemberInfo.AllowUserToAddRows = false;
            this.dgvMemberInfo.AllowUserToDeleteRows = false;
            this.dgvMemberInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMemberInfo.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.NAME,
            this.EMAIL,
            this.PHONE,
            this.PASSWORD,
            this.USERNAME,
            this.Column7});
            this.dgvMemberInfo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvMemberInfo.Location = new System.Drawing.Point(0, 0);
            this.dgvMemberInfo.Name = "dgvMemberInfo";
            this.dgvMemberInfo.ReadOnly = true;
            this.dgvMemberInfo.RowTemplate.Height = 25;
            this.dgvMemberInfo.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvMemberInfo.Size = new System.Drawing.Size(760, 229);
            this.dgvMemberInfo.TabIndex = 2;
            this.dgvMemberInfo.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvMemberInfo_CellContentClick);
            this.dgvMemberInfo.DoubleClick += new System.EventHandler(this.dgvMemberInfo_DoubleClick);
            // 
            // ID
            // 
            this.ID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ID.DataPropertyName = "Id";
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            // 
            // NAME
            // 
            this.NAME.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.NAME.DataPropertyName = "Name";
            this.NAME.HeaderText = "NAME";
            this.NAME.Name = "NAME";
            this.NAME.ReadOnly = true;
            // 
            // EMAIL
            // 
            this.EMAIL.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.EMAIL.DataPropertyName = "Email";
            this.EMAIL.HeaderText = "EMAIL";
            this.EMAIL.Name = "EMAIL";
            this.EMAIL.ReadOnly = true;
            // 
            // PHONE
            // 
            this.PHONE.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.PHONE.DataPropertyName = "Phone";
            this.PHONE.HeaderText = "PHONE";
            this.PHONE.Name = "PHONE";
            this.PHONE.ReadOnly = true;
            // 
            // PASSWORD
            // 
            this.PASSWORD.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.PASSWORD.DataPropertyName = "Password";
            this.PASSWORD.HeaderText = "PASSWORD";
            this.PASSWORD.Name = "PASSWORD";
            this.PASSWORD.ReadOnly = true;
            // 
            // USERNAME
            // 
            this.USERNAME.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.USERNAME.DataPropertyName = "UserName";
            this.USERNAME.HeaderText = "USERNAME";
            this.USERNAME.Name = "USERNAME";
            this.USERNAME.ReadOnly = true;
            // 
            // Column7
            // 
            this.Column7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column7.DataPropertyName = "ROLE";
            this.Column7.HeaderText = "ROLE";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            // 
            // mtbtnShowAll
            // 
            this.mtbtnShowAll.Location = new System.Drawing.Point(625, 251);
            this.mtbtnShowAll.Name = "mtbtnShowAll";
            this.mtbtnShowAll.Size = new System.Drawing.Size(155, 23);
            this.mtbtnShowAll.TabIndex = 1;
            this.mtbtnShowAll.Text = "Show All";
            this.mtbtnShowAll.UseSelectable = true;
            this.mtbtnShowAll.Click += new System.EventHandler(this.mtbtnShowAll_Click);
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(90, 13);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(154, 23);
            this.txtName.TabIndex = 2;
            // 
            // mtlblName
            // 
            this.mtlblName.AutoSize = true;
            this.mtlblName.Location = new System.Drawing.Point(15, 17);
            this.mtlblName.Name = "mtlblName";
            this.mtlblName.Size = new System.Drawing.Size(45, 19);
            this.mtlblName.TabIndex = 3;
            this.mtlblName.Text = "Name";
            // 
            // mtlblEmail
            // 
            this.mtlblEmail.AutoSize = true;
            this.mtlblEmail.Location = new System.Drawing.Point(15, 58);
            this.mtlblEmail.Name = "mtlblEmail";
            this.mtlblEmail.Size = new System.Drawing.Size(47, 19);
            this.mtlblEmail.TabIndex = 4;
            this.mtlblEmail.Text = "E-mail";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(90, 54);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(154, 23);
            this.txtEmail.TabIndex = 5;
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(91, 145);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(154, 23);
            this.txtPassword.TabIndex = 9;
            // 
            // mtlblPassword
            // 
            this.mtlblPassword.AutoSize = true;
            this.mtlblPassword.Location = new System.Drawing.Point(16, 149);
            this.mtlblPassword.Name = "mtlblPassword";
            this.mtlblPassword.Size = new System.Drawing.Size(63, 19);
            this.mtlblPassword.TabIndex = 8;
            this.mtlblPassword.Text = "Password";
            // 
            // mtlblPhone
            // 
            this.mtlblPhone.AutoSize = true;
            this.mtlblPhone.Location = new System.Drawing.Point(17, 108);
            this.mtlblPhone.Name = "mtlblPhone";
            this.mtlblPhone.Size = new System.Drawing.Size(46, 19);
            this.mtlblPhone.TabIndex = 7;
            this.mtlblPhone.Text = "Phone";
            // 
            // txtPhone
            // 
            this.txtPhone.Location = new System.Drawing.Point(91, 104);
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(154, 23);
            this.txtPhone.TabIndex = 6;
            // 
            // mtlblUserName
            // 
            this.mtlblUserName.AutoSize = true;
            this.mtlblUserName.Location = new System.Drawing.Point(17, 200);
            this.mtlblUserName.Name = "mtlblUserName";
            this.mtlblUserName.Size = new System.Drawing.Size(71, 19);
            this.mtlblUserName.TabIndex = 10;
            this.mtlblUserName.Text = "UserName";
            // 
            // txtUserName
            // 
            this.txtUserName.Location = new System.Drawing.Point(94, 196);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(154, 23);
            this.txtUserName.TabIndex = 11;
            // 
            // metroPanel2
            // 
            this.metroPanel2.Controls.Add(this.mtbtnDelete);
            this.metroPanel2.Controls.Add(this.mtbtnSave);
            this.metroPanel2.Controls.Add(this.mtlblUserName);
            this.metroPanel2.Controls.Add(this.txtUserName);
            this.metroPanel2.Controls.Add(this.txtPhone);
            this.metroPanel2.Controls.Add(this.txtPassword);
            this.metroPanel2.Controls.Add(this.txtName);
            this.metroPanel2.Controls.Add(this.mtlblPassword);
            this.metroPanel2.Controls.Add(this.mtlblName);
            this.metroPanel2.Controls.Add(this.mtlblPhone);
            this.metroPanel2.Controls.Add(this.mtlblEmail);
            this.metroPanel2.Controls.Add(this.txtEmail);
            this.metroPanel2.HorizontalScrollbarBarColor = true;
            this.metroPanel2.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel2.HorizontalScrollbarSize = 10;
            this.metroPanel2.Location = new System.Drawing.Point(12, 12);
            this.metroPanel2.Name = "metroPanel2";
            this.metroPanel2.Size = new System.Drawing.Size(264, 272);
            this.metroPanel2.TabIndex = 12;
            this.metroPanel2.VerticalScrollbarBarColor = true;
            this.metroPanel2.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel2.VerticalScrollbarSize = 10;
            this.metroPanel2.Paint += new System.Windows.Forms.PaintEventHandler(this.metroPanel2_Paint);
            // 
            // mtbtnDelete
            // 
            this.mtbtnDelete.Location = new System.Drawing.Point(30, 239);
            this.mtbtnDelete.Name = "mtbtnDelete";
            this.mtbtnDelete.Size = new System.Drawing.Size(77, 23);
            this.mtbtnDelete.TabIndex = 20;
            this.mtbtnDelete.Text = "Delete";
            this.mtbtnDelete.UseSelectable = true;
            this.mtbtnDelete.Click += new System.EventHandler(this.mtbtnDelete_Click);
            // 
            // mtbtnSave
            // 
            this.mtbtnSave.Location = new System.Drawing.Point(140, 239);
            this.mtbtnSave.Name = "mtbtnSave";
            this.mtbtnSave.Size = new System.Drawing.Size(91, 23);
            this.mtbtnSave.TabIndex = 19;
            this.mtbtnSave.Text = "Save";
            this.mtbtnSave.UseSelectable = true;
            this.mtbtnSave.Click += new System.EventHandler(this.mtbtnSave_Click);
            // 
            // txtSearchUname
            // 
            this.txtSearchUname.Location = new System.Drawing.Point(300, 46);
            this.txtSearchUname.Name = "txtSearchUname";
            this.txtSearchUname.PlaceholderText = "Search By UserName";
            this.txtSearchUname.Size = new System.Drawing.Size(176, 23);
            this.txtSearchUname.TabIndex = 15;
            // 
            // mtbtnSearch
            // 
            this.mtbtnSearch.Location = new System.Drawing.Point(521, 46);
            this.mtbtnSearch.Name = "mtbtnSearch";
            this.mtbtnSearch.Size = new System.Drawing.Size(67, 23);
            this.mtbtnSearch.TabIndex = 16;
            this.mtbtnSearch.Text = "Search";
            this.mtbtnSearch.UseSelectable = true;
            this.mtbtnSearch.Click += new System.EventHandler(this.mtbtnSearch_Click);
            // 
            // txtSearchRole
            // 
            this.txtSearchRole.Location = new System.Drawing.Point(300, 114);
            this.txtSearchRole.Name = "txtSearchRole";
            this.txtSearchRole.PlaceholderText = "Search By Role";
            this.txtSearchRole.Size = new System.Drawing.Size(176, 23);
            this.txtSearchRole.TabIndex = 17;
            // 
            // mtbtnSearchRole
            // 
            this.mtbtnSearchRole.Location = new System.Drawing.Point(521, 114);
            this.mtbtnSearchRole.Name = "mtbtnSearchRole";
            this.mtbtnSearchRole.Size = new System.Drawing.Size(155, 23);
            this.mtbtnSearchRole.TabIndex = 18;
            this.mtbtnSearchRole.Text = "Search";
            this.mtbtnSearchRole.UseSelectable = true;
            this.mtbtnSearchRole.Click += new System.EventHandler(this.mtbtnSearchRole_Click);
            // 
            // mtbtnUpdate
            // 
            this.mtbtnUpdate.Location = new System.Drawing.Point(608, 46);
            this.mtbtnUpdate.Name = "mtbtnUpdate";
            this.mtbtnUpdate.Size = new System.Drawing.Size(68, 23);
            this.mtbtnUpdate.TabIndex = 19;
            this.mtbtnUpdate.Text = "Update";
            this.mtbtnUpdate.UseSelectable = true;
            this.mtbtnUpdate.Click += new System.EventHandler(this.mtbtnUpdate_Click_1);
            // 
            // ShowAllUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 539);
            this.Controls.Add(this.mtbtnUpdate);
            this.Controls.Add(this.mtbtnSearchRole);
            this.Controls.Add(this.txtSearchRole);
            this.Controls.Add(this.mtbtnSearch);
            this.Controls.Add(this.txtSearchUname);
            this.Controls.Add(this.metroPanel2);
            this.Controls.Add(this.mtbtnShowAll);
            this.Controls.Add(this.metroPanel1);
            this.Name = "ShowAllUser";
            this.Text = "Admin DataBoard";
            this.metroPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvMemberInfo)).EndInit();
            this.metroPanel2.ResumeLayout(false);
            this.metroPanel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroPanel metroPanel1;
        private System.Windows.Forms.DataGridView dgvMemberInfo;
        private MetroFramework.Controls.MetroButton mtbtnShowAll;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn NAME;
        private System.Windows.Forms.DataGridViewTextBoxColumn EMAIL;
        private System.Windows.Forms.DataGridViewTextBoxColumn PHONE;
        private System.Windows.Forms.DataGridViewTextBoxColumn PASSWORD;
        private System.Windows.Forms.DataGridViewTextBoxColumn USERNAME;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private MetroFramework.Controls.MetroLabel mtlblName;
        private MetroFramework.Controls.MetroLabel mtlblEmail;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtPassword;
        private MetroFramework.Controls.MetroLabel mtlblPassword;
        private MetroFramework.Controls.MetroLabel mtlblPhone;
        private System.Windows.Forms.TextBox txtPhone;
        private MetroFramework.Controls.MetroLabel mtlblUserName;
        private System.Windows.Forms.TextBox txtUserName;
        private MetroFramework.Controls.MetroPanel metroPanel2;
        private System.Windows.Forms.TextBox txtSearchUname;
        private MetroFramework.Controls.MetroButton mtbtnSearch;
        private System.Windows.Forms.TextBox txtSearchRole;
        private MetroFramework.Controls.MetroButton mtbtnSearchRole;
        private MetroFramework.Controls.MetroButton mtbtnUpdate;
        private MetroFramework.Controls.MetroButton mtbtnSave;
        private MetroFramework.Controls.MetroButton mtbtnDelete;
    }
}