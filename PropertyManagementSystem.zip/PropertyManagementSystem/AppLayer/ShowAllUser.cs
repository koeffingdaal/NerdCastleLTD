﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using PropertyManagementSystem.DataLayer;
using PropertyManagementSystem.EntityLayer;
using PropertyManagementSystem.RepositoryLayer;

namespace PropertyManagementSystem.AppLayer
{
    public partial class ShowAllUser : MetroFramework.Forms.MetroForm
    {
        private DataAccess Da { get; set; }

        UserRepo uR = new UserRepo();
        UserEntity uE = new UserEntity();
        public ShowAllUser()
        {
            InitializeComponent();
            this.Da = new DataAccess();
           // PopulatedGridView();
        }

        private void mtbtnShowAll_Click(object sender, EventArgs e)
        {
            PopulatedGridView();
            
            
        }

        public void PopulatedGridView()
        {
           
                string sql = "select * from Registration;";
                Da.ExecuteQuery(sql);
                this.dgvMemberInfo.AutoGenerateColumns = false;

                this.dgvMemberInfo.DataSource = Da.Ds.Tables[0];
            
            
        }

        private void dgvMemberInfo_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvMemberInfo_DoubleClick(object sender, EventArgs e)
        {
            this.txtName.Text = this.dgvMemberInfo.CurrentRow.Cells["Name"].Value.ToString();
            this.txtEmail.Text = this.dgvMemberInfo.CurrentRow.Cells["Email"].Value.ToString();
            this.txtPhone.Text = this.dgvMemberInfo.CurrentRow.Cells["Phone"].Value.ToString();
            this.txtPassword.Text = this.dgvMemberInfo.CurrentRow.Cells["Password"].Value.ToString();
            this.txtUserName.Text = this.dgvMemberInfo.CurrentRow.Cells["UserName"].Value.ToString();
        }

        private void mtbtnUpdate_Click(object sender, EventArgs e)
        {
           

            uE.Name = this.txtName.Text;
            uE.Email = this.txtEmail.Text;
            uE.Phone = this.txtPhone.Text;
            uE.Password = this.txtPassword.Text;
            uE.UserName = this.txtUserName.Text;







            uR.Update();
        }

        private void mtbtnSearch_Click(object sender, EventArgs e)
        {
            SearchByUserName();
        }

        private void mtbtnSearchRole_Click(object sender, EventArgs e)
        {
            SearchByRole();
        }

        private void mtbtnUpdate_Click_1(object sender, EventArgs e)
        {
            string sql = "select * from Registration where UserName = '" + this.txtSearchUname.Text + "'; ";
            Da.GetDataSet(sql);
            this.dgvMemberInfo.AutoGenerateColumns = false;

            this.dgvMemberInfo.DataSource = Da.Ds.Tables[0];

            this.txtName.Text = Da.Ds.Tables[0].Rows[0][1].ToString();
            this.txtEmail.Text = Da.Ds.Tables[0].Rows[0][2].ToString();
            this.txtPhone.Text = Da.Ds.Tables[0].Rows[0][3].ToString();
            this.txtPassword.Text = Da.Ds.Tables[0].Rows[0][4].ToString();
            this.txtUserName.Text = Da.Ds.Tables[0].Rows[0][5].ToString();
        }

        private void mtbtnSave_Click(object sender, EventArgs e)
        {
            Update();
          
                 
        }

        public void SearchByUserName()
        {
            string sql = "select * from Registration where UserName = '" + this.txtSearchUname.Text + "'; ";
            Da.GetDataSet(sql);
            this.dgvMemberInfo.AutoGenerateColumns = false;

            this.dgvMemberInfo.DataSource = Da.Ds.Tables[0];
        }

        public void SearchByRole()
        {
            try
            {
                string sql = "select * from Registration where UserName = '" + this.txtSearchRole.Text + "'; ";
                Da.GetDataSet(sql);
                this.dgvMemberInfo.AutoGenerateColumns = false;

                this.dgvMemberInfo.DataSource = Da.Ds.Tables[0];
            }
            catch(Exception exc)
            {
                MessageBox.Show("Wrong Username");
            }
        }
        public void Update()
        {
            try
            {
                string sql = @"update Registration
                      SET Name = '" + this.txtName.Text + "', Email = '" + this.txtEmail.Text + "', Phone = '" + this.txtPhone.Text + "', Password = '" + this.txtPassword.Text + "' " +
                      "where UserName = '" + this.txtUserName.Text + "'; ";
                Da.ExecuteDMLQuery(sql);


                MessageBox.Show("Updated");
                PopulatedGridView();
            }
            catch(Exception exc)
            {
                MessageBox.Show("Update Failed");
            }
        }
        private void mtbtnDelete_Click(object sender, EventArgs e)
        {
            Delete();

        }

        public void Delete()
        {
            var sql = "DELETE FROM Registration WHERE UserName='" + this.txtUserName.Text + "';";
            Da.ExecuteDMLQuery(sql);
            PopulatedGridView();
        }

        private void metroPanel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
