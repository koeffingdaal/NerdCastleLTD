﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using PropertyManagementSystem.EntityLayer;
using PropertyManagementSystem.DataLayer;
using PropertyManagementSystem.RepositoryLayer;
namespace PropertyManagementSystem.AppLayer
{
    public partial class BuyerList : MetroFramework.Forms.MetroForm
    {
        private Admin Admin { get; set; }
        public BuyerList()
        {
            InitializeComponent();
        }
        public BuyerList(Admin admin)
        {
            InitializeComponent();
            this.Admin = admin;
        }

        private void mtbtnShowBuyer_Click(object sender, EventArgs e)
        {
            BuyerRepo allBuyer = new BuyerRepo();
            this.dgvAllBuyer.AutoGenerateColumns = false;

            this.dgvAllBuyer.DataSource = allBuyer.AllBuyer();
            this.dgvAllBuyer.ClearSelection();
           
        }

        private void mtbtnSearch_Click(object sender, EventArgs e)
        {
            try
            {

                if (IsValidToSearch())
                {
                    BuyerListEntity buyerEntity = new BuyerListEntity();
                    buyerEntity.SearchBuyerName = this.txtUnameSearch.Text;

                    BuyerRepo searchName = new BuyerRepo();
                    this.dgvAllBuyer.AutoGenerateColumns = false;
                    this.dgvAllBuyer.DataSource = searchName.SearchByName(buyerEntity.SearchBuyerName);
                }
                else
                {
                    MessageBox.Show("Insert Username");
                }
            }
            catch(Exception exc)
            {
                MessageBox.Show("Invalid Username");
            }
        }

        public bool IsValidToSearch()
        {
            if (this.txtUnameSearch.Text != null)
            {
                return true;
            }
            else
            {
                MessageBox.Show("Insert username");
                return false;
            }
        }

        private void mtbtnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            Admin.Show();
        }
    }
}
