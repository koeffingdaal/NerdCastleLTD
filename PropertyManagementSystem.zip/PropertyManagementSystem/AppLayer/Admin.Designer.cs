﻿
namespace PropertyManagementSystem.AppLayer
{
    partial class Admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mtpnlAdminDash = new MetroFramework.Controls.MetroPanel();
            this.mtlblOutPhone = new MetroFramework.Controls.MetroLabel();
            this.mtlblInPhone = new MetroFramework.Controls.MetroLabel();
            this.mtlblOutEmail = new MetroFramework.Controls.MetroLabel();
            this.mtlblInEmail = new MetroFramework.Controls.MetroLabel();
            this.mtlblOutName = new MetroFramework.Controls.MetroLabel();
            this.mtlblInName = new MetroFramework.Controls.MetroLabel();
            this.mtbtnShowAllUser = new MetroFramework.Controls.MetroButton();
            this.mtbtnBack = new MetroFramework.Controls.MetroButton();
            this.mtbtnAllBuyer = new MetroFramework.Controls.MetroButton();
            this.mtbtnUpdateBuyer = new MetroFramework.Controls.MetroButton();
            this.mtbtnAddBuyer = new MetroFramework.Controls.MetroButton();
            this.mtbtnDeleteBuyer = new MetroFramework.Controls.MetroButton();
            this.mtbtnAddOpenSpace = new MetroFramework.Controls.MetroButton();
            this.mtbtnUpdateOpenSpace = new MetroFramework.Controls.MetroButton();
            this.mtbtnDeleteOpenSpace = new MetroFramework.Controls.MetroButton();
            this.mtpnlAdminDash.SuspendLayout();
            this.SuspendLayout();
            // 
            // mtpnlAdminDash
            // 
            this.mtpnlAdminDash.Controls.Add(this.mtlblOutPhone);
            this.mtpnlAdminDash.Controls.Add(this.mtlblInPhone);
            this.mtpnlAdminDash.Controls.Add(this.mtlblOutEmail);
            this.mtpnlAdminDash.Controls.Add(this.mtlblInEmail);
            this.mtpnlAdminDash.Controls.Add(this.mtlblOutName);
            this.mtpnlAdminDash.Controls.Add(this.mtlblInName);
            this.mtpnlAdminDash.HorizontalScrollbarBarColor = true;
            this.mtpnlAdminDash.HorizontalScrollbarHighlightOnWheel = false;
            this.mtpnlAdminDash.HorizontalScrollbarSize = 10;
            this.mtpnlAdminDash.Location = new System.Drawing.Point(23, 63);
            this.mtpnlAdminDash.Name = "mtpnlAdminDash";
            this.mtpnlAdminDash.Size = new System.Drawing.Size(228, 364);
            this.mtpnlAdminDash.TabIndex = 0;
            this.mtpnlAdminDash.VerticalScrollbarBarColor = true;
            this.mtpnlAdminDash.VerticalScrollbarHighlightOnWheel = false;
            this.mtpnlAdminDash.VerticalScrollbarSize = 10;
            // 
            // mtlblOutPhone
            // 
            this.mtlblOutPhone.AutoSize = true;
            this.mtlblOutPhone.Location = new System.Drawing.Point(102, 170);
            this.mtlblOutPhone.Name = "mtlblOutPhone";
            this.mtlblOutPhone.Size = new System.Drawing.Size(52, 19);
            this.mtlblOutPhone.TabIndex = 7;
            this.mtlblOutPhone.Text = "*Phone";
            // 
            // mtlblInPhone
            // 
            this.mtlblInPhone.AutoSize = true;
            this.mtlblInPhone.Location = new System.Drawing.Point(19, 170);
            this.mtlblInPhone.Name = "mtlblInPhone";
            this.mtlblInPhone.Size = new System.Drawing.Size(46, 19);
            this.mtlblInPhone.TabIndex = 6;
            this.mtlblInPhone.Text = "Phone";
            // 
            // mtlblOutEmail
            // 
            this.mtlblOutEmail.AutoSize = true;
            this.mtlblOutEmail.Location = new System.Drawing.Point(102, 103);
            this.mtlblOutEmail.Name = "mtlblOutEmail";
            this.mtlblOutEmail.Size = new System.Drawing.Size(47, 19);
            this.mtlblOutEmail.TabIndex = 5;
            this.mtlblOutEmail.Text = "*Email";
            // 
            // mtlblInEmail
            // 
            this.mtlblInEmail.AutoSize = true;
            this.mtlblInEmail.Location = new System.Drawing.Point(19, 103);
            this.mtlblInEmail.Name = "mtlblInEmail";
            this.mtlblInEmail.Size = new System.Drawing.Size(41, 19);
            this.mtlblInEmail.TabIndex = 4;
            this.mtlblInEmail.Text = "Email";
            // 
            // mtlblOutName
            // 
            this.mtlblOutName.AutoSize = true;
            this.mtlblOutName.Location = new System.Drawing.Point(102, 33);
            this.mtlblOutName.Name = "mtlblOutName";
            this.mtlblOutName.Size = new System.Drawing.Size(51, 19);
            this.mtlblOutName.TabIndex = 3;
            this.mtlblOutName.Text = "*Name";
            // 
            // mtlblInName
            // 
            this.mtlblInName.AutoSize = true;
            this.mtlblInName.Location = new System.Drawing.Point(19, 33);
            this.mtlblInName.Name = "mtlblInName";
            this.mtlblInName.Size = new System.Drawing.Size(45, 19);
            this.mtlblInName.TabIndex = 2;
            this.mtlblInName.Text = "Name";
            this.mtlblInName.Click += new System.EventHandler(this.mtlblAdminName_Click);
            // 
            // mtbtnShowAllUser
            // 
            this.mtbtnShowAllUser.BackColor = System.Drawing.Color.Green;
            this.mtbtnShowAllUser.ForeColor = System.Drawing.SystemColors.Highlight;
            this.mtbtnShowAllUser.Location = new System.Drawing.Point(271, 80);
            this.mtbtnShowAllUser.Name = "mtbtnShowAllUser";
            this.mtbtnShowAllUser.Size = new System.Drawing.Size(81, 70);
            this.mtbtnShowAllUser.TabIndex = 1;
            this.mtbtnShowAllUser.Text = "Show All User";
            this.mtbtnShowAllUser.UseSelectable = true;
            this.mtbtnShowAllUser.UseVisualStyleBackColor = false;
            this.mtbtnShowAllUser.Click += new System.EventHandler(this.mtbtnManageMember_Click);
            // 
            // mtbtnBack
            // 
            this.mtbtnBack.Location = new System.Drawing.Point(702, 404);
            this.mtbtnBack.Name = "mtbtnBack";
            this.mtbtnBack.Size = new System.Drawing.Size(75, 23);
            this.mtbtnBack.TabIndex = 2;
            this.mtbtnBack.Text = "Back";
            this.mtbtnBack.UseSelectable = true;
            this.mtbtnBack.Click += new System.EventHandler(this.mtbtnBack_Click);
            // 
            // mtbtnAllBuyer
            // 
            this.mtbtnAllBuyer.BackColor = System.Drawing.Color.Green;
            this.mtbtnAllBuyer.ForeColor = System.Drawing.SystemColors.Highlight;
            this.mtbtnAllBuyer.Location = new System.Drawing.Point(445, 80);
            this.mtbtnAllBuyer.Name = "mtbtnAllBuyer";
            this.mtbtnAllBuyer.Size = new System.Drawing.Size(91, 70);
            this.mtbtnAllBuyer.TabIndex = 3;
            this.mtbtnAllBuyer.Text = "Show All Buyer";
            this.mtbtnAllBuyer.UseSelectable = true;
            this.mtbtnAllBuyer.UseVisualStyleBackColor = false;
            this.mtbtnAllBuyer.Click += new System.EventHandler(this.mtbtnAllBuyer_Click);
            // 
            // mtbtnUpdateBuyer
            // 
            this.mtbtnUpdateBuyer.BackColor = System.Drawing.Color.Green;
            this.mtbtnUpdateBuyer.ForeColor = System.Drawing.SystemColors.Highlight;
            this.mtbtnUpdateBuyer.Location = new System.Drawing.Point(542, 80);
            this.mtbtnUpdateBuyer.Name = "mtbtnUpdateBuyer";
            this.mtbtnUpdateBuyer.Size = new System.Drawing.Size(103, 70);
            this.mtbtnUpdateBuyer.TabIndex = 4;
            this.mtbtnUpdateBuyer.Text = "Update Buyer List";
            this.mtbtnUpdateBuyer.UseSelectable = true;
            this.mtbtnUpdateBuyer.UseVisualStyleBackColor = false;
            this.mtbtnUpdateBuyer.Click += new System.EventHandler(this.mtbtnUpdateBuyer_Click);
            // 
            // mtbtnAddBuyer
            // 
            this.mtbtnAddBuyer.BackColor = System.Drawing.Color.Green;
            this.mtbtnAddBuyer.ForeColor = System.Drawing.SystemColors.Highlight;
            this.mtbtnAddBuyer.Location = new System.Drawing.Point(358, 80);
            this.mtbtnAddBuyer.Name = "mtbtnAddBuyer";
            this.mtbtnAddBuyer.Size = new System.Drawing.Size(81, 70);
            this.mtbtnAddBuyer.TabIndex = 5;
            this.mtbtnAddBuyer.Text = "Add Buyer";
            this.mtbtnAddBuyer.UseSelectable = true;
            this.mtbtnAddBuyer.UseVisualStyleBackColor = false;
            this.mtbtnAddBuyer.Click += new System.EventHandler(this.mtbtnAddBuyer_Click);
            // 
            // mtbtnDeleteBuyer
            // 
            this.mtbtnDeleteBuyer.BackColor = System.Drawing.Color.Green;
            this.mtbtnDeleteBuyer.ForeColor = System.Drawing.SystemColors.Highlight;
            this.mtbtnDeleteBuyer.Location = new System.Drawing.Point(651, 80);
            this.mtbtnDeleteBuyer.Name = "mtbtnDeleteBuyer";
            this.mtbtnDeleteBuyer.Size = new System.Drawing.Size(91, 70);
            this.mtbtnDeleteBuyer.TabIndex = 6;
            this.mtbtnDeleteBuyer.Text = "Delete Buyer";
            this.mtbtnDeleteBuyer.UseSelectable = true;
            this.mtbtnDeleteBuyer.UseVisualStyleBackColor = false;
            this.mtbtnDeleteBuyer.Click += new System.EventHandler(this.mtbtnDeleteBuyer_Click);
            // 
            // mtbtnAddOpenSpace
            // 
            this.mtbtnAddOpenSpace.BackColor = System.Drawing.Color.Green;
            this.mtbtnAddOpenSpace.ForeColor = System.Drawing.SystemColors.Highlight;
            this.mtbtnAddOpenSpace.Location = new System.Drawing.Point(271, 195);
            this.mtbtnAddOpenSpace.Name = "mtbtnAddOpenSpace";
            this.mtbtnAddOpenSpace.Size = new System.Drawing.Size(105, 70);
            this.mtbtnAddOpenSpace.TabIndex = 7;
            this.mtbtnAddOpenSpace.Text = "Add Open Space";
            this.mtbtnAddOpenSpace.UseSelectable = true;
            this.mtbtnAddOpenSpace.UseVisualStyleBackColor = false;
            this.mtbtnAddOpenSpace.Click += new System.EventHandler(this.mtbtnAddOpenSpace_Click);
            // 
            // mtbtnUpdateOpenSpace
            // 
            this.mtbtnUpdateOpenSpace.BackColor = System.Drawing.Color.Green;
            this.mtbtnUpdateOpenSpace.ForeColor = System.Drawing.SystemColors.Highlight;
            this.mtbtnUpdateOpenSpace.Location = new System.Drawing.Point(382, 195);
            this.mtbtnUpdateOpenSpace.Name = "mtbtnUpdateOpenSpace";
            this.mtbtnUpdateOpenSpace.Size = new System.Drawing.Size(121, 70);
            this.mtbtnUpdateOpenSpace.TabIndex = 8;
            this.mtbtnUpdateOpenSpace.Text = "Update Open Space";
            this.mtbtnUpdateOpenSpace.UseSelectable = true;
            this.mtbtnUpdateOpenSpace.UseVisualStyleBackColor = false;
            this.mtbtnUpdateOpenSpace.Click += new System.EventHandler(this.mtbtnUpdateOpenSpace_Click);
            // 
            // mtbtnDeleteOpenSpace
            // 
            this.mtbtnDeleteOpenSpace.BackColor = System.Drawing.Color.Green;
            this.mtbtnDeleteOpenSpace.ForeColor = System.Drawing.SystemColors.Highlight;
            this.mtbtnDeleteOpenSpace.Location = new System.Drawing.Point(509, 195);
            this.mtbtnDeleteOpenSpace.Name = "mtbtnDeleteOpenSpace";
            this.mtbtnDeleteOpenSpace.Size = new System.Drawing.Size(108, 70);
            this.mtbtnDeleteOpenSpace.TabIndex = 9;
            this.mtbtnDeleteOpenSpace.Text = "Delete Open Space";
            this.mtbtnDeleteOpenSpace.UseSelectable = true;
            this.mtbtnDeleteOpenSpace.UseVisualStyleBackColor = false;
            this.mtbtnDeleteOpenSpace.Click += new System.EventHandler(this.mtbtnDeleteOpenSpace_Click);
            // 
            // Admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.mtbtnDeleteOpenSpace);
            this.Controls.Add(this.mtbtnUpdateOpenSpace);
            this.Controls.Add(this.mtbtnAddOpenSpace);
            this.Controls.Add(this.mtbtnDeleteBuyer);
            this.Controls.Add(this.mtbtnAddBuyer);
            this.Controls.Add(this.mtbtnUpdateBuyer);
            this.Controls.Add(this.mtbtnAllBuyer);
            this.Controls.Add(this.mtbtnBack);
            this.Controls.Add(this.mtbtnShowAllUser);
            this.Controls.Add(this.mtpnlAdminDash);
            this.Name = "Admin";
            this.Text = "Admin Dashboard";
            this.mtpnlAdminDash.ResumeLayout(false);
            this.mtpnlAdminDash.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroPanel mtpnlAdminDash;
        private MetroFramework.Controls.MetroLabel mtlblInName;
        private MetroFramework.Controls.MetroLabel mtlblOutName;
        private MetroFramework.Controls.MetroLabel mtlblOutPhone;
        private MetroFramework.Controls.MetroLabel mtlblInPhone;
        private MetroFramework.Controls.MetroLabel mtlblOutEmail;
        private MetroFramework.Controls.MetroLabel mtlblInEmail;
        private MetroFramework.Controls.MetroButton mtbtnShowAllUser;
        private MetroFramework.Controls.MetroButton mtbtnShowProfile;
        private MetroFramework.Controls.MetroButton mtbtnBack;
        private MetroFramework.Controls.MetroButton mtbtnAllBuyer;
        private MetroFramework.Controls.MetroButton mtbtnUpdateBuyer;
        private MetroFramework.Controls.MetroButton mtbtnAddBuyer;
        private MetroFramework.Controls.MetroButton mtbtnDeleteBuyer;
        private MetroFramework.Controls.MetroButton mtbtnAddOpenSpace;
        private MetroFramework.Controls.MetroButton mtbtnUpdateOpenSpace;
        private MetroFramework.Controls.MetroButton mtbtnDeleteOpenSpace;
    }
}