﻿
namespace PropertyManagementSystem.AppLayer
{
    partial class BuyerAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.mtbtnInsert = new MetroFramework.Controls.MetroButton();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.mtlblUname = new MetroFramework.Controls.MetroLabel();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.mtlblPhone = new MetroFramework.Controls.MetroLabel();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.mtlblEmail = new MetroFramework.Controls.MetroLabel();
            this.txtName = new System.Windows.Forms.TextBox();
            this.mtlblName = new MetroFramework.Controls.MetroLabel();
            this.mtbtnClear = new MetroFramework.Controls.MetroButton();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.mtbtnClear);
            this.panel1.Controls.Add(this.mtbtnInsert);
            this.panel1.Controls.Add(this.txtUserName);
            this.panel1.Controls.Add(this.mtlblUname);
            this.panel1.Controls.Add(this.txtPhone);
            this.panel1.Controls.Add(this.mtlblPhone);
            this.panel1.Controls.Add(this.txtEmail);
            this.panel1.Controls.Add(this.mtlblEmail);
            this.panel1.Controls.Add(this.txtName);
            this.panel1.Controls.Add(this.mtlblName);
            this.panel1.Location = new System.Drawing.Point(226, 63);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(284, 337);
            this.panel1.TabIndex = 0;
            // 
            // mtbtnInsert
            // 
            this.mtbtnInsert.Location = new System.Drawing.Point(15, 279);
            this.mtbtnInsert.Name = "mtbtnInsert";
            this.mtbtnInsert.Size = new System.Drawing.Size(124, 31);
            this.mtbtnInsert.TabIndex = 8;
            this.mtbtnInsert.Text = "Insert";
            this.mtbtnInsert.UseSelectable = true;
            this.mtbtnInsert.Click += new System.EventHandler(this.mtbtnInsert_Click);
            // 
            // txtUserName
            // 
            this.txtUserName.Location = new System.Drawing.Point(96, 162);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(155, 23);
            this.txtUserName.TabIndex = 7;
            // 
            // mtlblUname
            // 
            this.mtlblUname.AutoSize = true;
            this.mtlblUname.Location = new System.Drawing.Point(15, 166);
            this.mtlblUname.Name = "mtlblUname";
            this.mtlblUname.Size = new System.Drawing.Size(75, 19);
            this.mtlblUname.TabIndex = 6;
            this.mtlblUname.Text = "User Name";
            // 
            // txtPhone
            // 
            this.txtPhone.Location = new System.Drawing.Point(96, 113);
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(155, 23);
            this.txtPhone.TabIndex = 5;
            // 
            // mtlblPhone
            // 
            this.mtlblPhone.AutoSize = true;
            this.mtlblPhone.Location = new System.Drawing.Point(15, 113);
            this.mtlblPhone.Name = "mtlblPhone";
            this.mtlblPhone.Size = new System.Drawing.Size(46, 19);
            this.mtlblPhone.TabIndex = 4;
            this.mtlblPhone.Text = "Phone";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(96, 63);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(155, 23);
            this.txtEmail.TabIndex = 3;
            // 
            // mtlblEmail
            // 
            this.mtlblEmail.AutoSize = true;
            this.mtlblEmail.Location = new System.Drawing.Point(15, 63);
            this.mtlblEmail.Name = "mtlblEmail";
            this.mtlblEmail.Size = new System.Drawing.Size(41, 19);
            this.mtlblEmail.TabIndex = 2;
            this.mtlblEmail.Text = "Email";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(96, 19);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(155, 23);
            this.txtName.TabIndex = 1;
            // 
            // mtlblName
            // 
            this.mtlblName.AutoSize = true;
            this.mtlblName.Location = new System.Drawing.Point(15, 19);
            this.mtlblName.Name = "mtlblName";
            this.mtlblName.Size = new System.Drawing.Size(45, 19);
            this.mtlblName.TabIndex = 0;
            this.mtlblName.Text = "Name";
            // 
            // mtbtnClear
            // 
            this.mtbtnClear.Location = new System.Drawing.Point(145, 279);
            this.mtbtnClear.Name = "mtbtnClear";
            this.mtbtnClear.Size = new System.Drawing.Size(124, 31);
            this.mtbtnClear.TabIndex = 9;
            this.mtbtnClear.Text = "Clear";
            this.mtbtnClear.UseSelectable = true;
            this.mtbtnClear.Click += new System.EventHandler(this.mtbtnClear_Click);
            // 
            // BuyerAdd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel1);
            this.Name = "BuyerAdd";
            this.Text = "BuyerAdd";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtName;
        private MetroFramework.Controls.MetroLabel mtlblName;
        private System.Windows.Forms.TextBox txtPhone;
        private MetroFramework.Controls.MetroLabel mtlblPhone;
        private System.Windows.Forms.TextBox txtEmail;
        private MetroFramework.Controls.MetroLabel mtlblEmail;
        private System.Windows.Forms.TextBox txtUserName;
        private MetroFramework.Controls.MetroLabel mtlblUname;
        private MetroFramework.Controls.MetroButton mtbtnInsert;
        private MetroFramework.Controls.MetroButton mtbtnClear;
    }
}