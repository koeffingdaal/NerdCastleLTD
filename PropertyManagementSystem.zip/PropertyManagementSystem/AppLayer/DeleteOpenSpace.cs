﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using PropertyManagementSystem.EntityLayer;
using PropertyManagementSystem.RepositoryLayer;

namespace PropertyManagementSystem.AppLayer
{
    public partial class DeleteOpenSpace : MetroFramework.Forms.MetroForm
    {
        public DeleteOpenSpace()
        {
            InitializeComponent();
            PopulatedGridView();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void mtbtnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                OpenSearchAppIdEntity ose = new OpenSearchAppIdEntity();
                OpenSpaceRepo osr = new OpenSpaceRepo();

                ose.SearchAppId = this.txtAppId.Text;

                osr.DeleteOpenSpace(ose.SearchAppId);
               
                MessageBox.Show("Deleted");
            }
            catch(Exception exc)
            {
                MessageBox.Show("Not Deleted");
            }
        }

        private void dgvDeleteOpenSpace_DoubleClick(object sender, EventArgs e)
        {
            this.txtId.Text = this.dgvDeleteOpenSpace.CurrentRow.Cells["Id"].Value.ToString();
            this.txtAppId.Text = this.dgvDeleteOpenSpace.CurrentRow.Cells["AppId"].Value.ToString();
            this.txtArea.Text = this.dgvDeleteOpenSpace.CurrentRow.Cells["Area"].Value.ToString();
            this.txtDistrict.Text = this.dgvDeleteOpenSpace.CurrentRow.Cells["District"].Value.ToString();
            this.txtSize.Text = this.dgvDeleteOpenSpace.CurrentRow.Cells["Size"].Value.ToString();
            this.txtPrice.Text = this.dgvDeleteOpenSpace.CurrentRow.Cells["Price"].Value.ToString();
            this.mtdtIssueDate.Text = this.dgvDeleteOpenSpace.CurrentRow.Cells["IssueDate"].Value.ToString();

        }

        public void PopulatedGridView()
        {
            OpenSpaceRepo osr = new OpenSpaceRepo();
            this.dgvDeleteOpenSpace.AutoGenerateColumns = false;
            this.dgvDeleteOpenSpace.DataSource = osr.AllOpenSpace();
        }
    }
}
