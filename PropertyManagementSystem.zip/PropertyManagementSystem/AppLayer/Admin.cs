﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using PropertyManagementSystem.DataLayer;
using PropertyManagementSystem.EntityLayer;
using PropertyManagementSystem.ValidationLayer;
using PropertyManagementSystem.RepositoryLayer;

namespace PropertyManagementSystem.AppLayer
{
    public partial class Admin : MetroFramework.Forms.MetroForm
    {
        private LogIn LogIn { get; set; }
        AdminEntity adminEntity = new AdminEntity();
        //UserLogInEntity ule = new UserLogInEntity();
        public Admin()
        {
            InitializeComponent();

            

        }

        public Admin(LogIn login)
        {
            InitializeComponent();
            this.LogIn = login;


            this.mtlblOutName.Text = Name;
            //this.mtlblOutEmail.Text = Email;


        }

        public void ShowProfile()
        {
            
            


        }

        private void mtlblAdminName_Click(object sender, EventArgs e)
        {

        }

        private void mtbtnManageMember_Click(object sender, EventArgs e)
        {
            ShowAllUser mm = new ShowAllUser();
            mm.Show();
        }

        private void mtbtnShowProfile_Click(object sender, EventArgs e)
        {
            var profile = new LogInRepository();
            profile.ShowProfile();
        }

        private void mtbtnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            this.LogIn.Show();
        }

        private void mtbtnAllBuyer_Click(object sender, EventArgs e)
        {
            BuyerList buyerList = new BuyerList(this);
            this.Hide();
            buyerList.Show();
        }

        private void mtbtnUpdateBuyer_Click(object sender, EventArgs e)
        {
            BuyerUpdate buyerUpdate = new BuyerUpdate();
            buyerUpdate.Show();
        }

        private void mtbtnAddBuyer_Click(object sender, EventArgs e)
        {
            BuyerAdd buyerAdd = new BuyerAdd();
            buyerAdd.Show();
        }

        private void mtbtnDeleteBuyer_Click(object sender, EventArgs e)
        {
            BuyerDelete buyerDelete = new BuyerDelete(this);
            buyerDelete.Show();
        }

        private void mtbtnAddOpenSpace_Click(object sender, EventArgs e)
        {
            AddOpenSpace openSpaceAdd = new AddOpenSpace();
            openSpaceAdd.Show();
            
            
        }

        private void mtbtnUpdateOpenSpace_Click(object sender, EventArgs e)
        {
            UpdateOpenSpace updateOpenSpace = new UpdateOpenSpace();
            updateOpenSpace.Visible = true;
        }

        private void mtbtnDeleteOpenSpace_Click(object sender, EventArgs e)
        {
            DeleteOpenSpace deleteOpenSpace = new DeleteOpenSpace();
            deleteOpenSpace.Show();
        }
    }
}
