﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using PropertyManagementSystem.RepositoryLayer;
using PropertyManagementSystem.EntityLayer;

namespace PropertyManagementSystem.AppLayer
{
    public partial class BuyerUpdate : MetroFramework.Forms.MetroForm
    {
        public BuyerUpdate()
        {
            InitializeComponent();
        }
        private void metroPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void mtbtnAllBuyer_Click(object sender, EventArgs e)
        {
            BuyerRepo buyerRepo = new BuyerRepo();
            this.dgvBuyerUpdate.AutoGenerateColumns = false;
            this.dgvBuyerUpdate.DataSource = buyerRepo.AllBuyer();
        }

        

        private void dgvBuyerUpdate_DoubleClick(object sender, EventArgs e)
        {
            this.txtBuyerId.Text = dgvBuyerUpdate.CurrentRow.Cells["Id"].Value.ToString();
            this.txtBuyerUname.Text = dgvBuyerUpdate.CurrentRow.Cells["UserName"].Value.ToString();
            this.txtRole.Text = dgvBuyerUpdate.CurrentRow.Cells["Role"].Value.ToString();
            this.txtBuyerName.Text = dgvBuyerUpdate.CurrentRow.Cells["Name"].Value.ToString();
            this.txtBuyerEmail.Text = dgvBuyerUpdate.CurrentRow.Cells["Email"].Value.ToString();
            this.txtBuyerPhone.Text = dgvBuyerUpdate.CurrentRow.Cells["Phone"].Value.ToString();

            this.txtBuyerId.ReadOnly = true;
            this.txtBuyerUname.ReadOnly = true;
            this.txtRole.ReadOnly = true;


        }

        private void mtbtnSearch_Click(object sender, EventArgs e)
        {
            try
            {

                if (IsValidToSearch())
                {
                    BuyerListEntity buyerEntity = new BuyerListEntity();
                    buyerEntity.SearchBuyerName = txtSearchUname.Text;

                    BuyerRepo searchName = new BuyerRepo();
                    this.dgvBuyerUpdate.AutoGenerateColumns = false;
                    this.dgvBuyerUpdate.DataSource = searchName.SearchByName(buyerEntity.SearchBuyerName);
                }
                else
                {
                    MessageBox.Show("Insert Username");
                }
            }
            catch (Exception exc)
            {
                MessageBox.Show("Invalid Username");
            }
        }
        public bool IsValidToSearch()
        {
            if (this.txtSearchUname.Text != null)
            {
                return true;
            }
            else
            {
                MessageBox.Show("Insert username");
                return false;
            }
        }

        private void mtbtnBuyerUpdate_Click(object sender, EventArgs e)
        {
            BuyerListEntity buyerEntity = new BuyerListEntity();
            buyerEntity.BuyerUserName = this.txtBuyerUname.Text;
            buyerEntity.BuyerName = this.txtBuyerName.Text;
            buyerEntity.BuyerEmail = this.txtBuyerEmail.Text;
            buyerEntity.BuyerPhone = this.txtBuyerPhone.Text;

            BuyerRepo update = new BuyerRepo();
            update.BuyerUpdate( buyerEntity.BuyerName,  buyerEntity.BuyerEmail, buyerEntity.BuyerPhone, buyerEntity.BuyerUserName);

            MessageBox.Show("Updated");

        }

        public void ClearContent()
        {
            this.txtBuyerId.Clear();
            this.txtBuyerUname.Clear();
            this.txtBuyerPhone.Clear();
            this.txtRole.Clear();
            this.txtBuyerEmail.Clear();
            this.txtBuyerName.Clear();
        }

        private void mtbtnClear_Click(object sender, EventArgs e)
        {
            ClearContent();
        }
    }
}
