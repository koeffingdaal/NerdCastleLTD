﻿
namespace PropertyManagementSystem.AppLayer
{
    partial class Registration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.mtbtnClear = new MetroFramework.Controls.MetroButton();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.mtrbSeller = new MetroFramework.Controls.MetroRadioButton();
            this.mtrbBuyer = new MetroFramework.Controls.MetroRadioButton();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.mtlblUserName = new MetroFramework.Controls.MetroLabel();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.mtlblPassword = new MetroFramework.Controls.MetroLabel();
            this.mtbtnRegistration = new MetroFramework.Controls.MetroButton();
            this.mtlblRole = new MetroFramework.Controls.MetroLabel();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.mtlblPhone = new MetroFramework.Controls.MetroLabel();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.mtlblEmail = new MetroFramework.Controls.MetroLabel();
            this.txtName = new System.Windows.Forms.TextBox();
            this.mtlblName = new MetroFramework.Controls.MetroLabel();
            this.panel1.SuspendLayout();
            this.metroPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.mtbtnClear);
            this.panel1.Controls.Add(this.metroPanel1);
            this.panel1.Controls.Add(this.txtUserName);
            this.panel1.Controls.Add(this.mtlblUserName);
            this.panel1.Controls.Add(this.txtPassword);
            this.panel1.Controls.Add(this.mtlblPassword);
            this.panel1.Controls.Add(this.mtbtnRegistration);
            this.panel1.Controls.Add(this.mtlblRole);
            this.panel1.Controls.Add(this.txtPhone);
            this.panel1.Controls.Add(this.mtlblPhone);
            this.panel1.Controls.Add(this.txtEmail);
            this.panel1.Controls.Add(this.mtlblEmail);
            this.panel1.Controls.Add(this.txtName);
            this.panel1.Controls.Add(this.mtlblName);
            this.panel1.Location = new System.Drawing.Point(23, 63);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(741, 522);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // mtbtnClear
            // 
            this.mtbtnClear.Location = new System.Drawing.Point(474, 406);
            this.mtbtnClear.Name = "mtbtnClear";
            this.mtbtnClear.Size = new System.Drawing.Size(120, 23);
            this.mtbtnClear.TabIndex = 16;
            this.mtbtnClear.Text = "Clear";
            this.mtbtnClear.UseSelectable = true;
            this.mtbtnClear.Click += new System.EventHandler(this.mtbtnClear_Click);
            // 
            // metroPanel1
            // 
            this.metroPanel1.Controls.Add(this.mtrbSeller);
            this.metroPanel1.Controls.Add(this.mtrbBuyer);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(323, 30);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(150, 62);
            this.metroPanel1.TabIndex = 15;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // mtrbSeller
            // 
            this.mtrbSeller.AutoSize = true;
            this.mtrbSeller.Location = new System.Drawing.Point(3, 35);
            this.mtrbSeller.Name = "mtrbSeller";
            this.mtrbSeller.Size = new System.Drawing.Size(51, 15);
            this.mtrbSeller.TabIndex = 16;
            this.mtrbSeller.Text = "Seller";
            this.mtrbSeller.UseSelectable = true;
            // 
            // mtrbBuyer
            // 
            this.mtrbBuyer.AutoSize = true;
            this.mtrbBuyer.Location = new System.Drawing.Point(3, 4);
            this.mtrbBuyer.Name = "mtrbBuyer";
            this.mtrbBuyer.Size = new System.Drawing.Size(53, 15);
            this.mtrbBuyer.TabIndex = 3;
            this.mtrbBuyer.Text = "Buyer";
            this.mtrbBuyer.UseSelectable = true;
            // 
            // txtUserName
            // 
            this.txtUserName.Location = new System.Drawing.Point(324, 153);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(150, 23);
            this.txtUserName.TabIndex = 14;
            // 
            // mtlblUserName
            // 
            this.mtlblUserName.AutoSize = true;
            this.mtlblUserName.Location = new System.Drawing.Point(232, 157);
            this.mtlblUserName.Name = "mtlblUserName";
            this.mtlblUserName.Size = new System.Drawing.Size(75, 19);
            this.mtlblUserName.TabIndex = 13;
            this.mtlblUserName.Text = "User Name";
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(323, 199);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(150, 23);
            this.txtPassword.TabIndex = 12;
            // 
            // mtlblPassword
            // 
            this.mtlblPassword.AutoSize = true;
            this.mtlblPassword.Location = new System.Drawing.Point(232, 203);
            this.mtlblPassword.Name = "mtlblPassword";
            this.mtlblPassword.Size = new System.Drawing.Size(63, 19);
            this.mtlblPassword.TabIndex = 11;
            this.mtlblPassword.Text = "Password";
            // 
            // mtbtnRegistration
            // 
            this.mtbtnRegistration.Location = new System.Drawing.Point(244, 406);
            this.mtbtnRegistration.Name = "mtbtnRegistration";
            this.mtbtnRegistration.Size = new System.Drawing.Size(121, 23);
            this.mtbtnRegistration.TabIndex = 10;
            this.mtbtnRegistration.Text = "Registration";
            this.mtbtnRegistration.UseSelectable = true;
            this.mtbtnRegistration.Click += new System.EventHandler(this.mtbtnRegistration_Click);
            // 
            // mtlblRole
            // 
            this.mtlblRole.AutoSize = true;
            this.mtlblRole.Location = new System.Drawing.Point(232, 30);
            this.mtlblRole.Name = "mtlblRole";
            this.mtlblRole.Size = new System.Drawing.Size(35, 19);
            this.mtlblRole.TabIndex = 6;
            this.mtlblRole.Text = "Role";
            // 
            // txtPhone
            // 
            this.txtPhone.Location = new System.Drawing.Point(324, 257);
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(150, 23);
            this.txtPhone.TabIndex = 5;
            // 
            // mtlblPhone
            // 
            this.mtlblPhone.AutoSize = true;
            this.mtlblPhone.Location = new System.Drawing.Point(232, 261);
            this.mtlblPhone.Name = "mtlblPhone";
            this.mtlblPhone.Size = new System.Drawing.Size(46, 19);
            this.mtlblPhone.TabIndex = 4;
            this.mtlblPhone.Text = "Phone";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(318, 314);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(150, 23);
            this.txtEmail.TabIndex = 3;
            // 
            // mtlblEmail
            // 
            this.mtlblEmail.AutoSize = true;
            this.mtlblEmail.Location = new System.Drawing.Point(232, 318);
            this.mtlblEmail.Name = "mtlblEmail";
            this.mtlblEmail.Size = new System.Drawing.Size(41, 19);
            this.mtlblEmail.TabIndex = 2;
            this.mtlblEmail.Text = "Email";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(323, 109);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(150, 23);
            this.txtName.TabIndex = 1;
            // 
            // mtlblName
            // 
            this.mtlblName.AutoSize = true;
            this.mtlblName.Location = new System.Drawing.Point(233, 113);
            this.mtlblName.Name = "mtlblName";
            this.mtlblName.Size = new System.Drawing.Size(45, 19);
            this.mtlblName.TabIndex = 0;
            this.mtlblName.Text = "Name";
            this.mtlblName.Click += new System.EventHandler(this.mtlblName_Click);
            // 
            // Registration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(787, 596);
            this.Controls.Add(this.panel1);
            this.Name = "Registration";
            this.Text = "Registration";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private MetroFramework.Controls.MetroLabel mtlblName;
        private MetroFramework.Controls.MetroLabel mtlblRole;
        private System.Windows.Forms.TextBox txtPhone;
        private MetroFramework.Controls.MetroLabel mtlblPhone;
        private System.Windows.Forms.TextBox txtEmail;
        private MetroFramework.Controls.MetroLabel mtlblEmail;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtPassword;
        private MetroFramework.Controls.MetroLabel mtlblPassword;
        private MetroFramework.Controls.MetroButton mtbtnRegistration;
        private System.Windows.Forms.TextBox txtUserName;
        private MetroFramework.Controls.MetroLabel mtlblUserName;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private MetroFramework.Controls.MetroRadioButton mtrbSeller;
        private MetroFramework.Controls.MetroRadioButton mtrbBuyer;
        private MetroFramework.Controls.MetroButton mtbtnClear;
    }
}