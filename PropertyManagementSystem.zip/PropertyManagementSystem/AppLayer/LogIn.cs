﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using PropertyManagementSystem.EntityLayer;
using PropertyManagementSystem.ValidationLayer;
using PropertyManagementSystem.RepositoryLayer;


namespace PropertyManagementSystem.AppLayer
{
    public partial class LogIn : MetroFramework.Forms.MetroForm
    {
        public LogIn()
        {
            InitializeComponent();
        }

        private void mtbtnLogIn_Click(object sender, EventArgs e)
        {


            if (IsValidLogIn())
            {

                UserLogInEntity ule = new UserLogInEntity();

                ule.UserName = this.txtUserName.Text;
                ule.UserPassword = this.txtPassword.Text;

                MessageBox.Show("valid");


                LogInRepository lir = new LogInRepository();

                lir.UserLogIn(ule);
                Admin admin = new Admin(this);
                this.Hide();
                admin.Show();

            }

        }

        public bool IsValidLogIn()
        {
            if(this.txtUserName.Text != "" && this.txtPassword.Text != "")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private void mtbtnRegistration_Click(object sender, EventArgs e)
        {
            Registration reg = new Registration();
            this.Hide();
            reg.Show();
            
        }
    }
}
