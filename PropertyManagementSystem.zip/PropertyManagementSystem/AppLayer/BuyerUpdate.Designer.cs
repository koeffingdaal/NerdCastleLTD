﻿
namespace PropertyManagementSystem.AppLayer
{
    partial class BuyerUpdate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.dgvBuyerUpdate = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EMAIL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PHONE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.USERNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ROLE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mtbtnAllBuyer = new MetroFramework.Controls.MetroButton();
            this.metroPanel2 = new MetroFramework.Controls.MetroPanel();
            this.mtbtnBuyerUpdate = new MetroFramework.Controls.MetroButton();
            this.txtRole = new System.Windows.Forms.TextBox();
            this.mtlblRole = new MetroFramework.Controls.MetroLabel();
            this.txtBuyerUname = new System.Windows.Forms.TextBox();
            this.mtlblBuyerUname = new MetroFramework.Controls.MetroLabel();
            this.txtBuyerPhone = new System.Windows.Forms.TextBox();
            this.mtlblBuyerPhone = new MetroFramework.Controls.MetroLabel();
            this.txtBuyerEmail = new System.Windows.Forms.TextBox();
            this.txtBuyerName = new System.Windows.Forms.TextBox();
            this.txtBuyerId = new System.Windows.Forms.TextBox();
            this.mtlblBuyerEmail = new MetroFramework.Controls.MetroLabel();
            this.mtlblBuyerName = new MetroFramework.Controls.MetroLabel();
            this.mtlblBuyerId = new MetroFramework.Controls.MetroLabel();
            this.txtSearchUname = new System.Windows.Forms.TextBox();
            this.mtbtnSearch = new MetroFramework.Controls.MetroButton();
            this.mtbtnClear = new MetroFramework.Controls.MetroButton();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBuyerUpdate)).BeginInit();
            this.metroPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // metroPanel1
            // 
            this.metroPanel1.Controls.Add(this.dgvBuyerUpdate);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(23, 254);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(706, 278);
            this.metroPanel1.TabIndex = 0;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // dgvBuyerUpdate
            // 
            this.dgvBuyerUpdate.AllowUserToAddRows = false;
            this.dgvBuyerUpdate.AllowUserToDeleteRows = false;
            this.dgvBuyerUpdate.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBuyerUpdate.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.NAME,
            this.EMAIL,
            this.PHONE,
            this.USERNAME,
            this.ROLE});
            this.dgvBuyerUpdate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvBuyerUpdate.Location = new System.Drawing.Point(0, 0);
            this.dgvBuyerUpdate.Name = "dgvBuyerUpdate";
            this.dgvBuyerUpdate.ReadOnly = true;
            this.dgvBuyerUpdate.RowTemplate.Height = 25;
            this.dgvBuyerUpdate.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvBuyerUpdate.Size = new System.Drawing.Size(706, 278);
            this.dgvBuyerUpdate.TabIndex = 2;
            this.dgvBuyerUpdate.DoubleClick += new System.EventHandler(this.dgvBuyerUpdate_DoubleClick);
            // 
            // ID
            // 
            this.ID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ID.DataPropertyName = "Id";
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            // 
            // NAME
            // 
            this.NAME.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.NAME.DataPropertyName = "Name";
            this.NAME.HeaderText = "NAME";
            this.NAME.Name = "NAME";
            this.NAME.ReadOnly = true;
            // 
            // EMAIL
            // 
            this.EMAIL.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.EMAIL.DataPropertyName = "Email";
            this.EMAIL.HeaderText = "EMAIL";
            this.EMAIL.Name = "EMAIL";
            this.EMAIL.ReadOnly = true;
            // 
            // PHONE
            // 
            this.PHONE.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.PHONE.DataPropertyName = "Phone";
            this.PHONE.HeaderText = "PHONE";
            this.PHONE.Name = "PHONE";
            this.PHONE.ReadOnly = true;
            // 
            // USERNAME
            // 
            this.USERNAME.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.USERNAME.DataPropertyName = "UserName";
            this.USERNAME.HeaderText = "USERNAME";
            this.USERNAME.Name = "USERNAME";
            this.USERNAME.ReadOnly = true;
            // 
            // ROLE
            // 
            this.ROLE.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ROLE.DataPropertyName = "Role";
            this.ROLE.HeaderText = "ROLE";
            this.ROLE.Name = "ROLE";
            this.ROLE.ReadOnly = true;
            // 
            // mtbtnAllBuyer
            // 
            this.mtbtnAllBuyer.Location = new System.Drawing.Point(654, 73);
            this.mtbtnAllBuyer.Name = "mtbtnAllBuyer";
            this.mtbtnAllBuyer.Size = new System.Drawing.Size(75, 23);
            this.mtbtnAllBuyer.TabIndex = 1;
            this.mtbtnAllBuyer.Text = "All Buyer";
            this.mtbtnAllBuyer.UseSelectable = true;
            this.mtbtnAllBuyer.Click += new System.EventHandler(this.mtbtnAllBuyer_Click);
            // 
            // metroPanel2
            // 
            this.metroPanel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.metroPanel2.Controls.Add(this.mtbtnBuyerUpdate);
            this.metroPanel2.Controls.Add(this.txtRole);
            this.metroPanel2.Controls.Add(this.mtlblRole);
            this.metroPanel2.Controls.Add(this.txtBuyerUname);
            this.metroPanel2.Controls.Add(this.mtlblBuyerUname);
            this.metroPanel2.Controls.Add(this.txtBuyerPhone);
            this.metroPanel2.Controls.Add(this.mtlblBuyerPhone);
            this.metroPanel2.Controls.Add(this.txtBuyerEmail);
            this.metroPanel2.Controls.Add(this.txtBuyerName);
            this.metroPanel2.Controls.Add(this.txtBuyerId);
            this.metroPanel2.Controls.Add(this.mtlblBuyerEmail);
            this.metroPanel2.Controls.Add(this.mtlblBuyerName);
            this.metroPanel2.Controls.Add(this.mtlblBuyerId);
            this.metroPanel2.HorizontalScrollbarBarColor = true;
            this.metroPanel2.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel2.HorizontalScrollbarSize = 10;
            this.metroPanel2.Location = new System.Drawing.Point(23, 63);
            this.metroPanel2.Name = "metroPanel2";
            this.metroPanel2.Size = new System.Drawing.Size(612, 185);
            this.metroPanel2.TabIndex = 2;
            this.metroPanel2.VerticalScrollbarBarColor = true;
            this.metroPanel2.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel2.VerticalScrollbarSize = 10;
            this.metroPanel2.Paint += new System.Windows.Forms.PaintEventHandler(this.metroPanel2_Paint);
            // 
            // mtbtnBuyerUpdate
            // 
            this.mtbtnBuyerUpdate.Location = new System.Drawing.Point(444, 147);
            this.mtbtnBuyerUpdate.Name = "mtbtnBuyerUpdate";
            this.mtbtnBuyerUpdate.Size = new System.Drawing.Size(152, 31);
            this.mtbtnBuyerUpdate.TabIndex = 5;
            this.mtbtnBuyerUpdate.Text = "Update";
            this.mtbtnBuyerUpdate.UseSelectable = true;
            this.mtbtnBuyerUpdate.Click += new System.EventHandler(this.mtbtnBuyerUpdate_Click);
            // 
            // txtRole
            // 
            this.txtRole.Location = new System.Drawing.Point(53, 143);
            this.txtRole.Name = "txtRole";
            this.txtRole.Size = new System.Drawing.Size(104, 23);
            this.txtRole.TabIndex = 13;
            // 
            // mtlblRole
            // 
            this.mtlblRole.AutoSize = true;
            this.mtlblRole.Location = new System.Drawing.Point(12, 147);
            this.mtlblRole.Name = "mtlblRole";
            this.mtlblRole.Size = new System.Drawing.Size(35, 19);
            this.mtlblRole.TabIndex = 12;
            this.mtlblRole.Text = "Role";
            // 
            // txtBuyerUname
            // 
            this.txtBuyerUname.Location = new System.Drawing.Point(89, 79);
            this.txtBuyerUname.Name = "txtBuyerUname";
            this.txtBuyerUname.Size = new System.Drawing.Size(85, 23);
            this.txtBuyerUname.TabIndex = 11;
            // 
            // mtlblBuyerUname
            // 
            this.mtlblBuyerUname.AutoSize = true;
            this.mtlblBuyerUname.Location = new System.Drawing.Point(12, 79);
            this.mtlblBuyerUname.Name = "mtlblBuyerUname";
            this.mtlblBuyerUname.Size = new System.Drawing.Size(71, 19);
            this.mtlblBuyerUname.TabIndex = 10;
            this.mtlblBuyerUname.Text = "UserName";
            // 
            // txtBuyerPhone
            // 
            this.txtBuyerPhone.Location = new System.Drawing.Point(279, 147);
            this.txtBuyerPhone.Name = "txtBuyerPhone";
            this.txtBuyerPhone.Size = new System.Drawing.Size(127, 23);
            this.txtBuyerPhone.TabIndex = 9;
            // 
            // mtlblBuyerPhone
            // 
            this.mtlblBuyerPhone.AutoSize = true;
            this.mtlblBuyerPhone.Location = new System.Drawing.Point(195, 147);
            this.mtlblBuyerPhone.Name = "mtlblBuyerPhone";
            this.mtlblBuyerPhone.Size = new System.Drawing.Size(83, 19);
            this.mtlblBuyerPhone.TabIndex = 8;
            this.mtlblBuyerPhone.Text = "Buyer Phone";
            // 
            // txtBuyerEmail
            // 
            this.txtBuyerEmail.Location = new System.Drawing.Point(279, 79);
            this.txtBuyerEmail.Name = "txtBuyerEmail";
            this.txtBuyerEmail.Size = new System.Drawing.Size(127, 23);
            this.txtBuyerEmail.TabIndex = 7;
            // 
            // txtBuyerName
            // 
            this.txtBuyerName.Location = new System.Drawing.Point(279, 10);
            this.txtBuyerName.Name = "txtBuyerName";
            this.txtBuyerName.Size = new System.Drawing.Size(127, 23);
            this.txtBuyerName.TabIndex = 6;
            // 
            // txtBuyerId
            // 
            this.txtBuyerId.Location = new System.Drawing.Point(39, 6);
            this.txtBuyerId.Name = "txtBuyerId";
            this.txtBuyerId.Size = new System.Drawing.Size(56, 23);
            this.txtBuyerId.TabIndex = 5;
            // 
            // mtlblBuyerEmail
            // 
            this.mtlblBuyerEmail.AutoSize = true;
            this.mtlblBuyerEmail.Location = new System.Drawing.Point(195, 79);
            this.mtlblBuyerEmail.Name = "mtlblBuyerEmail";
            this.mtlblBuyerEmail.Size = new System.Drawing.Size(78, 19);
            this.mtlblBuyerEmail.TabIndex = 4;
            this.mtlblBuyerEmail.Text = "Buyer Email";
            // 
            // mtlblBuyerName
            // 
            this.mtlblBuyerName.AutoSize = true;
            this.mtlblBuyerName.Location = new System.Drawing.Point(195, 10);
            this.mtlblBuyerName.Name = "mtlblBuyerName";
            this.mtlblBuyerName.Size = new System.Drawing.Size(82, 19);
            this.mtlblBuyerName.TabIndex = 3;
            this.mtlblBuyerName.Text = "Buyer Name";
            // 
            // mtlblBuyerId
            // 
            this.mtlblBuyerId.AutoSize = true;
            this.mtlblBuyerId.Location = new System.Drawing.Point(12, 10);
            this.mtlblBuyerId.Name = "mtlblBuyerId";
            this.mtlblBuyerId.Size = new System.Drawing.Size(21, 19);
            this.mtlblBuyerId.TabIndex = 2;
            this.mtlblBuyerId.Text = "ID";
            // 
            // txtSearchUname
            // 
            this.txtSearchUname.Location = new System.Drawing.Point(424, 26);
            this.txtSearchUname.Name = "txtSearchUname";
            this.txtSearchUname.PlaceholderText = "Search by UserName";
            this.txtSearchUname.Size = new System.Drawing.Size(211, 23);
            this.txtSearchUname.TabIndex = 3;
            // 
            // mtbtnSearch
            // 
            this.mtbtnSearch.Location = new System.Drawing.Point(654, 26);
            this.mtbtnSearch.Name = "mtbtnSearch";
            this.mtbtnSearch.Size = new System.Drawing.Size(75, 23);
            this.mtbtnSearch.TabIndex = 4;
            this.mtbtnSearch.Text = "Search";
            this.mtbtnSearch.UseSelectable = true;
            this.mtbtnSearch.Click += new System.EventHandler(this.mtbtnSearch_Click);
            // 
            // mtbtnClear
            // 
            this.mtbtnClear.Location = new System.Drawing.Point(654, 210);
            this.mtbtnClear.Name = "mtbtnClear";
            this.mtbtnClear.Size = new System.Drawing.Size(75, 23);
            this.mtbtnClear.TabIndex = 5;
            this.mtbtnClear.Text = "Clear Section";
            this.mtbtnClear.UseSelectable = true;
            this.mtbtnClear.Click += new System.EventHandler(this.mtbtnClear_Click);
            // 
            // BuyerUpdate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(752, 555);
            this.Controls.Add(this.mtbtnClear);
            this.Controls.Add(this.mtbtnSearch);
            this.Controls.Add(this.txtSearchUname);
            this.Controls.Add(this.metroPanel2);
            this.Controls.Add(this.mtbtnAllBuyer);
            this.Controls.Add(this.metroPanel1);
            this.Name = "BuyerUpdate";
            this.Text = "BuyerUpdate";
            this.metroPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvBuyerUpdate)).EndInit();
            this.metroPanel2.ResumeLayout(false);
            this.metroPanel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroPanel metroPanel1;
        private System.Windows.Forms.DataGridView dgvBuyerUpdate;
        private MetroFramework.Controls.MetroButton mtbtnAllBuyer;
        private MetroFramework.Controls.MetroPanel metroPanel2;
        private MetroFramework.Controls.MetroLabel mtlblBuyerEmail;
        private MetroFramework.Controls.MetroLabel mtlblBuyerName;
        private MetroFramework.Controls.MetroLabel mtlblBuyerId;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn NAME;
        private System.Windows.Forms.DataGridViewTextBoxColumn EMAIL;
        private System.Windows.Forms.DataGridViewTextBoxColumn PHONE;
        private System.Windows.Forms.DataGridViewTextBoxColumn USERNAME;
        private System.Windows.Forms.DataGridViewTextBoxColumn ROLE;
        private System.Windows.Forms.TextBox txtBuyerName;
        private System.Windows.Forms.TextBox txtBuyerId;
        private System.Windows.Forms.TextBox txtBuyerEmail;
        private System.Windows.Forms.TextBox txtRole;
        private MetroFramework.Controls.MetroLabel mtlblRole;
        private System.Windows.Forms.TextBox txtBuyerUname;
        private MetroFramework.Controls.MetroLabel mtlblBuyerUname;
        private System.Windows.Forms.TextBox txtBuyerPhone;
        private MetroFramework.Controls.MetroLabel mtlblBuyerPhone;
        private System.Windows.Forms.TextBox txtSearchUname;
        private MetroFramework.Controls.MetroButton mtbtnSearch;
        private MetroFramework.Controls.MetroButton mtbtnBuyerUpdate;
        private MetroFramework.Controls.MetroButton mtbtnClear;
    }
}