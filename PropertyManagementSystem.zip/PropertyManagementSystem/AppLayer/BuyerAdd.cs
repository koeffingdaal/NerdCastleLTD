﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using PropertyManagementSystem.EntityLayer;
using PropertyManagementSystem.RepositoryLayer;

namespace PropertyManagementSystem.AppLayer
{
    public partial class BuyerAdd : MetroFramework.Forms.MetroForm
    {
        public BuyerAdd()
        {
            InitializeComponent();
        }

        private void mtbtnInsert_Click(object sender, EventArgs e)
        {
            try
            {
                BuyerListEntity buyerEntity = new BuyerListEntity();
                buyerEntity.BuyerName = this.txtName.Text;
                buyerEntity.BuyerEmail = this.txtEmail.Text;
                buyerEntity.BuyerPhone = this.txtPhone.Text;
                buyerEntity.BuyerUserName = this.txtUserName.Text;

                BuyerRepo addBuyer = new BuyerRepo();
                addBuyer.BuyerAdd(buyerEntity.BuyerName, buyerEntity.BuyerEmail, buyerEntity.BuyerPhone, buyerEntity.BuyerUserName);

                MessageBox.Show("Inserted");
            }
            catch(Exception exc)
            {
                MessageBox.Show("Not Insert");
            }
        }

        private void mtbtnClear_Click(object sender, EventArgs e)
        {
            ClearContent();
        }

        public void ClearContent()
        {
            this.txtName.Clear();
            this.txtEmail.Clear();
            this.txtPhone.Clear();
            this.txtUserName.Clear();
        }
    }
}
