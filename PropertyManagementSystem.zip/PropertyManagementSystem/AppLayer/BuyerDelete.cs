﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using PropertyManagementSystem.RepositoryLayer;
using PropertyManagementSystem.EntityLayer;

namespace PropertyManagementSystem.AppLayer
{
    public partial class BuyerDelete : MetroFramework.Forms.MetroForm
    {
        private Admin Admin { get; set; }
        public BuyerDelete()
        {
            InitializeComponent();
        }
        public BuyerDelete(Admin admin)
        {
            InitializeComponent();
            this.Admin = admin;
        }

        private void mtbtnAllBuyer_Click(object sender, EventArgs e)
        {
            BuyerRepo buyerRepo = new BuyerRepo();
            this.dgvBuyerDelete.AutoGenerateColumns = false;
            this.dgvBuyerDelete.DataSource = buyerRepo.AllBuyer();
        }

        private void mtbtnSearchBuyer_Click(object sender, EventArgs e)
        {
            BuyerListEntity buyerListEntity = new BuyerListEntity();
            var serachBuyer = new BuyerRepo();

            buyerListEntity.BuyerUserName = this.txtSearchUname.Text;

            this.dgvBuyerDelete.DataSource = serachBuyer.SearchByName(buyerListEntity.BuyerUserName);


        }

        private void mtbtnDelete_Click(object sender, EventArgs e)
        {
            BuyerListEntity buyerEntity = new BuyerListEntity();
            buyerEntity.SearchBuyerName = this.txtUserName.Text;

            BuyerRepo deleteBuyer = new BuyerRepo();
            deleteBuyer.DeleteBuyer(buyerEntity.SearchBuyerName);

            MessageBox.Show("Deleted");
        }

        private void dgvBuyerDelete_DoubleClick(object sender, EventArgs e)
        {
            this.txtId.Text = this.dgvBuyerDelete.CurrentRow.Cells["Id"].Value.ToString();
            this.txtName.Text = this.dgvBuyerDelete.CurrentRow.Cells["Name"].Value.ToString();
            this.txtEmail.Text = this.dgvBuyerDelete.CurrentRow.Cells["Email"].Value.ToString();
            this.txtUserName.Text = this.dgvBuyerDelete.CurrentRow.Cells["UserName"].Value.ToString();
            this.txtRole.Text = this.dgvBuyerDelete.CurrentRow.Cells["Role"].Value.ToString();
            this.txtPhone.Text = this.dgvBuyerDelete.CurrentRow.Cells["Phone"].Value.ToString();

            this.txtId.ReadOnly = true;
            this.txtName.ReadOnly = true;
            this.txtEmail.ReadOnly = true;
            this.txtUserName.ReadOnly = true;
            this.txtRole.ReadOnly = true;
            this.txtPhone.ReadOnly = true;





        }

        private void mtbtnClearContent_Click(object sender, EventArgs e)
        {
            ClearContent();
        }

        public void ClearContent()
        {
            this.txtId.Clear();
            this.txtName.Clear();
            this.txtEmail.Clear();
            this.txtPhone.Clear();
            this.txtUserName.Clear();
            this.txtRole.Clear();


        }

        private void mtbtnBack_Click(object sender, EventArgs e)
        {
            
            this.Hide();
            this.Admin.Show();

        }
    }
}
